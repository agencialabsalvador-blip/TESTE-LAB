import { createClient } from '@/lib/supabase/client'
import type {
  Event,
  EventSettings,
  EventCosts,
  Sponsor,
  Sale,
  BarSettings,
  BarSales,
  Scenario,
  Alert,
  EventCardData,
  DashboardSummary,
} from '@/types'
import {
  calcEventKPIs,
  calcDaysLeft,
  generateScenarios,
  generateAlerts,
} from '@/lib/calculations'

const supabase = createClient()

// ─── Events CRUD ─────────────────────────────────────────────────────────────

export async function getEvents(empresaId: string): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*, event_settings(*), costs(*), sponsors(*), bar_settings(*)')
    .eq('empresa_id', empresaId)
    .neq('status', 'arquivado')
    .order('data', { ascending: true })

  if (error) throw error
  return data ?? []
}

export async function getEvent(id: string): Promise<Event | null> {
  const { data, error } = await supabase
    .from('events')
    .select(
      `*, 
       event_settings(*), 
       costs(*), 
       sponsors(*), 
       bar_settings(*),
       scenarios(*)`
    )
    .eq('id', id)
    .single()

  if (error) return null
  return data
}

export async function createEvent(
  empresaId: string,
  payload: Partial<Event>
): Promise<Event> {
  const slug = payload.nome!
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')

  const { data, error } = await supabase
    .from('events')
    .insert({ ...payload, empresa_id: empresaId, slug })
    .select()
    .single()

  if (error) throw error

  // Create default settings
  await supabase.from('event_settings').insert({
    evento_id: data.id,
    ticket_medio_ingresso: 0,
    ticket_medio_ab: 100,
    participacao_lab: 0.5,
    meta_receita: 0,
    meta_publico: payload.capacidade ?? 0,
    publico_conservador: 0,
    publico_realista: 0,
    publico_agressivo: 0,
    publico_atual: 0,
    cortesias: 0,
    imposto_bilheteria: 0.08,
  })

  // Create default costs
  await supabase.from('costs').insert({
    evento_id: data.id,
    artistico: 0, estrutura: 0, marketing: 0,
    producao: 0, equipe: 0, operacao: 0,
    impostos: 0, outros: 0,
  })

  // Create default bar settings
  await supabase.from('bar_settings').insert({
    evento_id: data.id,
    ticket_medio: 100,
    participacao_empresa: 0.5,
  })

  return data
}

export async function updateEvent(id: string, payload: Partial<Event>) {
  const { error } = await supabase
    .from('events')
    .update(payload)
    .eq('id', id)
  if (error) throw error
}

export async function updateEventSettings(
  eventoId: string,
  payload: Partial<EventSettings>
) {
  const { error } = await supabase
    .from('event_settings')
    .update(payload)
    .eq('evento_id', eventoId)
  if (error) throw error
}

export async function updateCosts(eventoId: string, payload: Partial<EventCosts>) {
  const { error } = await supabase
    .from('costs')
    .update(payload)
    .eq('evento_id', eventoId)
  if (error) throw error
}

export async function archiveEvent(id: string) {
  await updateEvent(id, { status: 'arquivado' })
}

export async function duplicateEvent(id: string): Promise<Event> {
  const original = await getEvent(id)
  if (!original) throw new Error('Evento não encontrado')

  const { id: _id, created_at, updated_at, slug, ...rest } = original
  const copy = await createEvent(original.empresa_id, {
    ...rest,
    nome: `${original.nome} (cópia)`,
    status: 'aguardando',
  })

  return copy
}

// ─── Sponsors ────────────────────────────────────────────────────────────────

export async function getSponsors(eventoId: string): Promise<Sponsor[]> {
  const { data, error } = await supabase
    .from('sponsors')
    .select('*')
    .eq('evento_id', eventoId)
    .order('valor', { ascending: false })
  if (error) throw error
  return data ?? []
}

export async function upsertSponsor(
  eventoId: string,
  payload: Partial<Sponsor>
): Promise<Sponsor> {
  const { data, error } = await supabase
    .from('sponsors')
    .upsert({ ...payload, evento_id: eventoId })
    .select()
    .single()
  if (error) throw error
  return data
}

export async function deleteSponsor(id: string) {
  const { error } = await supabase.from('sponsors').delete().eq('id', id)
  if (error) throw error
}

// ─── Sales ───────────────────────────────────────────────────────────────────

export async function getSalesSummary(eventoId: string) {
  const { data: sales, error } = await supabase
    .from('sales')
    .select('*')
    .eq('evento_id', eventoId)
    .eq('status', 'confirmado')

  if (error) throw error

  const total_ingressos = (sales ?? []).reduce((a, s) => a + s.quantidade, 0)
  const valor_bruto = (sales ?? []).reduce((a, s) => a + s.valor_bruto, 0)
  const valor_liquido = (sales ?? []).reduce((a, s) => a + s.valor_liquido, 0)
  const ticket_medio = total_ingressos ? valor_liquido / total_ingressos : 0

  // Group by lote
  const loteMap = new Map<string, { quantidade: number; valor: number }>()
  ;(sales ?? []).forEach((s) => {
    const prev = loteMap.get(s.lote) ?? { quantidade: 0, valor: 0 }
    loteMap.set(s.lote, {
      quantidade: prev.quantidade + s.quantidade,
      valor: prev.valor + s.valor_liquido,
    })
  })

  const por_lote = Array.from(loteMap.entries()).map(([lote, v]) => ({
    lote,
    quantidade: v.quantidade,
    valor_total: v.valor,
    ticket_medio: v.quantidade ? v.valor / v.quantidade : 0,
  }))

  // Group by platform
  const platMap = new Map<string, { quantidade: number; valor: number }>()
  ;(sales ?? []).forEach((s) => {
    const prev = platMap.get(s.plataforma) ?? { quantidade: 0, valor: 0 }
    platMap.set(s.plataforma, {
      quantidade: prev.quantidade + s.quantidade,
      valor: prev.valor + s.valor_liquido,
    })
  })

  const por_plataforma = Array.from(platMap.entries()).map(([plataforma, v]) => ({
    plataforma,
    quantidade: v.quantidade,
    valor_total: v.valor,
  }))

  // Daily sales (last 30 days)
  const dailyMap = new Map<string, { ingressos: number; receita: number }>()
  ;(sales ?? []).forEach((s) => {
    const prev = dailyMap.get(s.data) ?? { ingressos: 0, receita: 0 }
    dailyMap.set(s.data, {
      ingressos: prev.ingressos + s.quantidade,
      receita: prev.receita + s.valor_liquido,
    })
  })

  const historico_diario = Array.from(dailyMap.entries())
    .map(([data, v]) => ({ data, ...v }))
    .sort((a, b) => a.data.localeCompare(b.data))

  return {
    total_ingressos,
    valor_bruto,
    valor_liquido,
    ticket_medio,
    por_lote,
    por_plataforma,
    historico_diario,
  }
}

// ─── Bar ─────────────────────────────────────────────────────────────────────

export async function getBarSales(eventoId: string): Promise<BarSales[]> {
  const { data, error } = await supabase
    .from('bar_sales')
    .select('*')
    .eq('evento_id', eventoId)
    .order('data', { ascending: false })
  if (error) throw error
  return data ?? []
}

export async function addBarSale(eventoId: string, payload: Partial<BarSales>) {
  const { error } = await supabase
    .from('bar_sales')
    .insert({ ...payload, evento_id: eventoId })
  if (error) throw error
}

// ─── Dashboard Summary ────────────────────────────────────────────────────────

export async function getDashboardSummary(
  empresaId: string
): Promise<DashboardSummary> {
  const events = await getEvents(empresaId)

  const activeEvents = events.filter((e) => e.status !== 'arquivado')

  const eventCards: EventCardData[] = activeEvents.map((ev) => {
    const settings = ev.settings
    const costs = ev.costs
    const sponsors = ev.sponsors ?? []

    const patrocinioTotal = sponsors.reduce((a, s) => a + s.valor, 0)
    const patrocinioConf = sponsors
      .filter((s) => s.status === 'confirmado')
      .reduce((a, s) => a + s.valor, 0)

    const publicoAtual = settings?.publico_atual ?? 0
    const publicoProjetado = settings?.publico_realista ?? 0
    const ticketIngresso = settings?.ticket_medio_ingresso ?? 0
    const ticketAB = settings?.ticket_medio_ab ?? 100
    const labShare = settings?.participacao_lab ?? 0.5
    const capacidade = ev.capacidade

    const bilheteriaProj = publicoProjetado * ticketIngresso
    const barProj = publicoProjetado * ticketAB * labShare
    const valorEconomico = bilheteriaProj + barProj + patrocinioTotal

    const custoTotal = costs
      ? costs.artistico + costs.estrutura + costs.marketing +
        costs.producao + costs.equipe + costs.operacao +
        costs.impostos + costs.outros
      : 0

    const resultadoProjetado = valorEconomico - custoTotal
    const metaAtingida = settings?.meta_receita
      ? Math.min(100, (bilheteriaProj / settings.meta_receita) * 100)
      : 0
    const diasRestantes = calcDaysLeft(ev.data)
    const ocupacao = capacidade ? (publicoAtual / capacidade) * 100 : 0

    return {
      id: ev.id,
      nome: ev.nome,
      data: ev.data,
      cidade: ev.cidade,
      local: ev.local,
      capacidade,
      publico_atual: publicoAtual,
      status: ev.status,
      imagem_url: ev.imagem_url,
      resultado_projetado: resultadoProjetado,
      meta_atingida_pct: metaAtingida,
      dias_restantes: diasRestantes,
      ocupacao_pct: ocupacao,
      valor_economico: valorEconomico,
      patrocinio_total: patrocinioTotal,
    }
  })

  const activeCards = eventCards.filter(
    (e) => e.status !== 'aguardando'
  )

  const valor_economico_total = activeCards.reduce(
    (a, e) => a + e.valor_economico,
    0
  )
  const receita_realizada = activeCards.reduce(
    (a, e) => a + e.publico_atual * (events.find((ev) => ev.id === e.id)?.settings?.ticket_medio_ingresso ?? 0),
    0
  )
  const resultado_projetado = activeCards.reduce(
    (a, e) => a + e.resultado_projetado,
    0
  )

  const saude =
    activeCards.length > 0
      ? Math.round(
          activeCards.reduce((a, e) => {
            const score =
              e.status === 'saudavel' ? 100
              : e.status === 'realizado' ? 80
              : e.status === 'atencao' ? 55
              : e.status === 'critico' ? 25
              : 0
            return a + score
          }, 0) / activeCards.length
        )
      : 0

  return {
    valor_economico_total,
    receita_realizada,
    resultado_projetado,
    saude_geral: saude,
    total_eventos_ativos: activeCards.length,
    eventos: eventCards,
  }
}
