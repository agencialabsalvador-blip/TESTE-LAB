import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import type { ImportRow, ImportPlatform } from '@/types'
import { createClient } from '@/lib/supabase/client'

const supabase = createClient()

// ─── Column Mappings per Platform ────────────────────────────────────────────

const PLATFORM_MAPPINGS: Record<
  string,
  Record<string, keyof ImportRow>
> = {
  bilheteria_digital: {
    'Cliente': 'cliente',
    'Lote': 'lote',
    'Quantidade': 'quantidade',
    'Valor Bruto': 'valor_bruto',
    'Taxa': 'taxa',
    'Valor Líquido': 'valor_liquido',
    'Data': 'data',
    'Hora': 'hora',
    'Canal': 'canal',
    'Cupom': 'cupom',
    'Status': 'status',
  },
  sympla: {
    'Nome': 'cliente',
    'Ingresso': 'lote',
    'Qtd': 'quantidade',
    'Valor': 'valor_bruto',
    'Taxa de serviço': 'taxa',
    'Valor líquido': 'valor_liquido',
    'Data da compra': 'data',
    'Status': 'status',
  },
  ingresse: {
    'Comprador': 'cliente',
    'Setor': 'lote',
    'Quantidade': 'quantidade',
    'Total': 'valor_bruto',
    'Taxa': 'taxa',
    'Repasse': 'valor_liquido',
    'Data': 'data',
    'Status': 'status',
  },
  generic: {
    'cliente': 'cliente',
    'lote': 'lote',
    'quantidade': 'quantidade',
    'valor_bruto': 'valor_bruto',
    'taxa': 'taxa',
    'valor_liquido': 'valor_liquido',
    'data': 'data',
    'hora': 'hora',
    'canal': 'canal',
    'cupom': 'cupom',
    'status': 'status',
  },
}

// ─── Parse CSV ────────────────────────────────────────────────────────────────

export async function parseCSV(file: File): Promise<Record<string, string>[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => resolve(results.data as Record<string, string>[]),
      error: reject,
    })
  })
}

// ─── Parse Excel ─────────────────────────────────────────────────────────────

export async function parseExcel(
  file: File
): Promise<Record<string, string>[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target!.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array' })
        const sheet = workbook.Sheets[workbook.SheetNames[0]]
        const json = XLSX.utils.sheet_to_json<Record<string, string>>(sheet, {
          raw: false,
          defval: '',
        })
        resolve(json)
      } catch (err) {
        reject(err)
      }
    }
    reader.onerror = reject
    reader.readAsArrayBuffer(file)
  })
}

// ─── Map Rows ─────────────────────────────────────────────────────────────────

function mapRow(
  raw: Record<string, string>,
  platform: ImportPlatform
): ImportRow | null {
  const mapping =
    PLATFORM_MAPPINGS[platform] ?? PLATFORM_MAPPINGS.generic

  const row: Partial<ImportRow> = {
    plataforma: platform,
    status: 'confirmado',
    quantidade: 1,
    taxa: 0,
  }

  for (const [rawKey, mappedKey] of Object.entries(mapping)) {
    // Case-insensitive key lookup
    const val = raw[rawKey] ?? raw[rawKey.toLowerCase()] ?? ''
    if (val === undefined || val === '') continue

    if (
      mappedKey === 'quantidade' ||
      mappedKey === 'valor_bruto' ||
      mappedKey === 'taxa' ||
      mappedKey === 'valor_liquido'
    ) {
      const num = parseFloat(
        String(val).replace(/[R$\s.]/g, '').replace(',', '.')
      )
      row[mappedKey] = isNaN(num) ? 0 : num
    } else {
      ;(row as Record<string, string>)[mappedKey] = String(val)
    }
  }

  // Infer valor_liquido if missing
  if (!row.valor_liquido && row.valor_bruto) {
    row.valor_liquido = (row.valor_bruto ?? 0) - (row.taxa ?? 0)
  }

  if (!row.lote || !row.data) return null

  return row as ImportRow
}

// ─── Import File ──────────────────────────────────────────────────────────────

export async function importFile(
  file: File,
  eventoId: string,
  empresaId: string,
  platform: ImportPlatform
): Promise<{ imported: number; errors: { linha: number; mensagem: string }[] }> {
  let rawRows: Record<string, string>[] = []

  if (file.name.endsWith('.csv')) {
    rawRows = await parseCSV(file)
  } else if (file.name.match(/\.xlsx?$/)) {
    rawRows = await parseExcel(file)
  } else {
    throw new Error('Formato não suportado. Use CSV ou Excel.')
  }

  const rows: ImportRow[] = []
  const errors: { linha: number; mensagem: string }[] = []

  rawRows.forEach((raw, idx) => {
    const row = mapRow(raw, platform)
    if (!row) {
      errors.push({
        linha: idx + 2,
        mensagem: 'Linha ignorada: campos obrigatórios ausentes (lote, data)',
      })
    } else {
      rows.push(row)
    }
  })

  if (rows.length === 0) {
    throw new Error('Nenhum registro válido encontrado no arquivo.')
  }

  // Batch insert
  const BATCH = 200
  let imported = 0

  for (let i = 0; i < rows.length; i += BATCH) {
    const batch = rows.slice(i, i + BATCH).map((r) => ({
      ...r,
      evento_id: eventoId,
      empresa_id: empresaId,
    }))

    const { error } = await supabase.from('sales').insert(batch)
    if (error) {
      errors.push({ linha: i, mensagem: error.message })
    } else {
      imported += batch.length
    }
  }

  // Update publico_atual in event_settings
  const { data: countData } = await supabase
    .from('sales')
    .select('quantidade')
    .eq('evento_id', eventoId)
    .eq('status', 'confirmado')

  const totalIngressos =
    countData?.reduce((a, s) => a + s.quantidade, 0) ?? 0

  await supabase
    .from('event_settings')
    .update({ publico_atual: totalIngressos })
    .eq('evento_id', eventoId)

  // Log import job
  await supabase.from('import_jobs').insert({
    evento_id: eventoId,
    empresa_id: empresaId,
    plataforma: platform,
    arquivo: file.name,
    status: errors.length > 0 ? 'concluido_com_erros' : 'concluido',
    total_registros: rawRows.length,
    registros_importados: imported,
    erros: errors,
  })

  return { imported, errors }
}

// ─── Template Download ────────────────────────────────────────────────────────

export function downloadTemplate() {
  const headers = [
    'lote', 'quantidade', 'valor_bruto', 'taxa',
    'valor_liquido', 'data', 'hora', 'cliente',
    'canal', 'cupom', 'status',
  ]

  const example = [
    'Lote 1', '2', '280.00', '14.00',
    '266.00', '2026-01-15', '14:30', 'João Silva',
    'online', '', 'confirmado',
  ]

  const ws = XLSX.utils.aoa_to_sheet([headers, example])
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Importação')
  XLSX.writeFile(wb, 'template_lab_intelligence.xlsx')
}
