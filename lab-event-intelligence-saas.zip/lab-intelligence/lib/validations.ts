import { z } from 'zod'

// ─── Auth ─────────────────────────────────────────────────────────────────────

export const loginSchema = z.object({
  email: z.string().email('E-mail inválido'),
  password: z.string().min(6, 'Senha deve ter no mínimo 6 caracteres'),
})

export const cadastroSchema = z.object({
  nome: z.string().min(2, 'Nome deve ter no mínimo 2 caracteres'),
  email: z.string().email('E-mail inválido'),
  password: z.string().min(8, 'Senha deve ter no mínimo 8 caracteres'),
  confirmPassword: z.string(),
  empresa_nome: z.string().min(2, 'Nome da empresa é obrigatório'),
}).refine((d) => d.password === d.confirmPassword, {
  message: 'Senhas não coincidem',
  path: ['confirmPassword'],
})

export const esqueceuSenhaSchema = z.object({
  email: z.string().email('E-mail inválido'),
})

export const trocaSenhaSchema = z.object({
  password: z.string().min(8, 'Senha deve ter no mínimo 8 caracteres'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: 'Senhas não coincidem',
  path: ['confirmPassword'],
})

// ─── Event ────────────────────────────────────────────────────────────────────

export const createEventSchema = z.object({
  nome: z.string().min(2, 'Nome é obrigatório'),
  data: z.string().min(1, 'Data é obrigatória'),
  cidade: z.string().min(2, 'Cidade é obrigatória'),
  local: z.string().min(2, 'Local é obrigatório'),
  capacidade: z.coerce.number().min(1, 'Capacidade deve ser maior que 0'),
  imagem_url: z.string().optional(),
  observacoes: z.string().optional(),
})

export const eventSettingsSchema = z.object({
  ticket_medio_ingresso: z.coerce.number().min(0),
  ticket_medio_ab: z.coerce.number().min(0),
  participacao_lab: z.coerce.number().min(0).max(1),
  meta_receita: z.coerce.number().min(0),
  meta_publico: z.coerce.number().min(0),
  publico_conservador: z.coerce.number().min(0),
  publico_realista: z.coerce.number().min(0),
  publico_agressivo: z.coerce.number().min(0),
  publico_atual: z.coerce.number().min(0),
  cortesias: z.coerce.number().min(0),
  imposto_bilheteria: z.coerce.number().min(0).max(1),
})

// ─── Costs ────────────────────────────────────────────────────────────────────

export const costsSchema = z.object({
  artistico: z.coerce.number().min(0),
  estrutura: z.coerce.number().min(0),
  marketing: z.coerce.number().min(0),
  producao: z.coerce.number().min(0),
  equipe: z.coerce.number().min(0),
  operacao: z.coerce.number().min(0),
  impostos: z.coerce.number().min(0),
  outros: z.coerce.number().min(0),
})

// ─── Sponsors ────────────────────────────────────────────────────────────────

export const sponsorSchema = z.object({
  empresa: z.string().min(2, 'Nome do patrocinador é obrigatório'),
  valor: z.coerce.number().min(0, 'Valor deve ser positivo'),
  status: z.enum(['confirmado', 'pendente', 'negociando', 'cancelado']),
  data_confirmacao: z.string().optional(),
  observacoes: z.string().optional(),
})

// ─── Bar Settings ─────────────────────────────────────────────────────────────

export const barSettingsSchema = z.object({
  ticket_medio: z.coerce.number().min(0),
  participacao_empresa: z.coerce.number().min(0).max(1),
})

// ─── System Settings ─────────────────────────────────────────────────────────

export const systemSettingSchema = z.object({
  chave: z.string().min(1),
  valor: z.string().min(0),
  tipo: z.enum(['string', 'number', 'boolean', 'json', 'color']),
  descricao: z.string().optional(),
  grupo: z.string().min(1),
})

// ─── User ─────────────────────────────────────────────────────────────────────

export const userSchema = z.object({
  nome: z.string().min(2),
  email: z.string().email(),
  cargo: z.string().optional(),
  perfil: z.enum(['admin', 'financeiro', 'producao', 'marketing', 'visualizacao']),
})

// ─── Import ───────────────────────────────────────────────────────────────────

export const importRowSchema = z.object({
  lote: z.string().min(1),
  quantidade: z.coerce.number().min(1),
  valor_bruto: z.coerce.number().min(0),
  taxa: z.coerce.number().min(0),
  valor_liquido: z.coerce.number().min(0),
  data: z.string().min(1),
  status: z.string().default('confirmado'),
  plataforma: z.string().default('csv'),
  cliente: z.string().optional(),
  canal: z.string().optional(),
  cupom: z.string().optional(),
  hora: z.string().optional(),
})

// ─── Type Exports ─────────────────────────────────────────────────────────────

export type LoginInput = z.infer<typeof loginSchema>
export type CadastroInput = z.infer<typeof cadastroSchema>
export type EsqueceuSenhaInput = z.infer<typeof esqueceuSenhaSchema>
export type CreateEventInput = z.infer<typeof createEventSchema>
export type EventSettingsInput = z.infer<typeof eventSettingsSchema>
export type CostsInput = z.infer<typeof costsSchema>
export type SponsorInput = z.infer<typeof sponsorSchema>
export type BarSettingsInput = z.infer<typeof barSettingsSchema>
export type ImportRowInput = z.infer<typeof importRowSchema>
