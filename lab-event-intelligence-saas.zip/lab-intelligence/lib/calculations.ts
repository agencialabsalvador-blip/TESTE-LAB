import type {
  EventSettings,
  EventCosts,
  Sponsor,
  EventKPIs,
  Scenario,
} from '@/types'

// ─── Core Formulas ───────────────────────────────────────────────────────────

export function calcBarRevenue(
  publico: number,
  ticketMedio: number,
  participacao: number
): number {
  return publico * ticketMedio * participacao
}

export function calcBilheteria(
  publico: number,
  ticketMedio: number,
  imposto = 0
): number {
  const bruto = publico * ticketMedio
  return bruto * (1 - imposto)
}

export function calcValorEconomico(
  bilheteria: number,
  bar: number,
  patrocinio: number,
  outras: number
): number {
  return bilheteria + bar + patrocinio + outras
}

export function calcResultado(receita: number, custos: number): number {
  return receita - custos
}

export function calcMargem(resultado: number, receita: number): number {
  if (!receita) return 0
  return (resultado / receita) * 100
}

export function calcROI(resultado: number, investimento: number): number {
  if (!investimento) return 0
  return (resultado / investimento) * 100
}

export function calcBreakeven(
  custos: number,
  ticketIngresso: number,
  ticketAB: number,
  participacaoLab: number
): number {
  const receitaPorPessoa = ticketIngresso + ticketAB * participacaoLab
  if (!receitaPorPessoa) return 0
  return Math.ceil(custos / receitaPorPessoa)
}

export function calcOcupacao(publicoAtual: number, capacidade: number): number {
  if (!capacidade) return 0
  return Math.min(100, (publicoAtual / capacidade) * 100)
}

export function calcMetaAtingida(
  receitaAtual: number,
  metaReceita: number
): number {
  if (!metaReceita) return 0
  return Math.min(100, (receitaAtual / metaReceita) * 100)
}

export function calcDaysLeft(dataEvento: string): number {
  const hoje = new Date()
  const evento = new Date(dataEvento)
  const diff = Math.ceil(
    (evento.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24)
  )
  return Math.max(0, diff)
}

export function calcVelocidadeVendas(
  ingressosVendidos: number,
  diasDecorridos: number
): number {
  if (!diasDecorridos) return 0
  return ingressosVendidos / diasDecorridos
}

export function calcMetaDiaria(
  ingressosFaltando: number,
  diasRestantes: number
): number {
  if (!diasRestantes) return ingressosFaltando
  return Math.ceil(ingressosFaltando / diasRestantes)
}

// ─── Full KPI Calculation ─────────────────────────────────────────────────────

export function calcEventKPIs(
  settings: EventSettings,
  costs: EventCosts,
  sponsors: Sponsor[],
  bilheteriaLiquida: number,
  receitaBar: number,
  outrasReceitas = 0
): EventKPIs {
  const custoTotal =
    costs.artistico +
    costs.estrutura +
    costs.marketing +
    costs.producao +
    costs.equipe +
    costs.operacao +
    costs.impostos +
    costs.outros

  const patrocinioConfirmado = sponsors
    .filter((s) => s.status === 'confirmado')
    .reduce((a, s) => a + s.valor, 0)

  const patrocinioTotal = sponsors.reduce((a, s) => a + s.valor, 0)

  // Projected (realistic scenario)
  const publicoProjetado = settings.publico_realista
  const bilheteiraProjetada = calcBilheteria(
    publicoProjetado,
    settings.ticket_medio_ingresso,
    settings.imposto_bilheteria
  )
  const barProjetado = calcBarRevenue(
    publicoProjetado,
    settings.ticket_medio_ab,
    settings.participacao_lab
  )

  const valorEconomicoTotal = calcValorEconomico(
    bilheteiraProjetada,
    barProjetado,
    patrocinioTotal,
    outrasReceitas
  )

  const receitaRealizada =
    bilheteriaLiquida + receitaBar + patrocinioConfirmado + outrasReceitas

  const resultadoProjetado = calcResultado(valorEconomicoTotal, custoTotal)
  const resultadoRealizado = calcResultado(receitaRealizada, custoTotal)

  const diasRestantes = calcDaysLeft(new Date().toISOString()) // will be overridden
  const ocupacao = calcOcupacao(settings.publico_atual, settings.meta_publico || 1)
  const metaAtingida = calcMetaAtingida(receitaRealizada, settings.meta_receita)

  const breakeven = calcBreakeven(
    custoTotal,
    settings.ticket_medio_ingresso,
    settings.ticket_medio_ab,
    settings.participacao_lab
  )

  return {
    bilheteria_bruta:
      settings.publico_atual * settings.ticket_medio_ingresso,
    bilheteria_liquida: bilheteriaLiquida,
    receita_bar: receitaBar,
    receita_patrocinios: patrocinioConfirmado,
    outras_receitas: outrasReceitas,
    valor_economico_total: valorEconomicoTotal,
    receita_realizada: receitaRealizada,
    custo_total: custoTotal,
    resultado_projetado: resultadoProjetado,
    resultado_realizado: resultadoRealizado,
    margem: calcMargem(resultadoProjetado, valorEconomicoTotal),
    roi: calcROI(resultadoProjetado, custoTotal),
    ticket_medio_ingresso: settings.ticket_medio_ingresso,
    ticket_medio_ab: settings.ticket_medio_ab,
    publico_atual: settings.publico_atual,
    publico_projetado: publicoProjetado,
    capacidade: settings.meta_publico,
    ocupacao_pct: ocupacao,
    meta_receita: settings.meta_receita,
    meta_atingida_pct: metaAtingida,
    breakeven_publico: breakeven,
    dias_restantes: 0, // set by caller
    velocidade_vendas: 0,
    meta_diaria: 0,
  }
}

// ─── Scenario Generation ─────────────────────────────────────────────────────

export function generateScenarios(
  settings: EventSettings,
  costs: EventCosts,
  patrocinioTotal: number,
  outrasReceitas = 0
): Omit<Scenario, 'id' | 'evento_id' | 'created_at' | 'updated_at'>[] {
  const custoTotal =
    costs.artistico + costs.estrutura + costs.marketing +
    costs.producao + costs.equipe + costs.operacao +
    costs.impostos + costs.outros

  const makeScenario = (
    tipo: 'conservador' | 'realista' | 'agressivo',
    publico: number
  ) => {
    const bilheteria = calcBilheteria(
      publico,
      settings.ticket_medio_ingresso,
      settings.imposto_bilheteria
    )
    const bar = calcBarRevenue(
      publico,
      settings.ticket_medio_ab,
      settings.participacao_lab
    )
    const receita = bilheteria + bar + patrocinioTotal + outrasReceitas
    const resultado = receita - custoTotal
    const margem = calcMargem(resultado, receita)
    const roi = calcROI(resultado, custoTotal)

    const risco: 'saudavel' | 'atencao' | 'critico' =
      roi > 40 ? 'saudavel' : roi > 0 ? 'atencao' : 'critico'

    const recomendacoes = {
      saudavel: 'Evento viável. Foque em maximizar receita de bar e patrocínios.',
      atencao: 'Margem apertada. Revise custos e acelere vendas de ingressos.',
      critico: 'Viabilidade em risco. Ação imediata necessária: reduzir custos ou aumentar captação.',
    }

    return {
      tipo,
      publico,
      bilheteria,
      bar,
      patrocinio: patrocinioTotal,
      outras_receitas: outrasReceitas,
      custos: custoTotal,
      margem,
      roi,
      risco,
      recomendacao: recomendacoes[risco],
    }
  }

  return [
    makeScenario('conservador', settings.publico_conservador),
    makeScenario('realista', settings.publico_realista),
    makeScenario('agressivo', settings.publico_agressivo),
  ]
}

// ─── Alert Generation ─────────────────────────────────────────────────────────

export function generateAlerts(
  kpis: EventKPIs,
  diasRestantes: number
): { nivel: 'saudavel' | 'atencao' | 'critico'; titulo: string; descricao: string; acao?: string }[] {
  const alerts = []

  // Breakeven distance
  if (kpis.publico_atual < kpis.breakeven_publico * 0.5) {
    alerts.push({
      nivel: 'critico' as const,
      titulo: 'Break-even muito distante',
      descricao: `Faltam ${(kpis.breakeven_publico - kpis.publico_atual).toLocaleString('pt-BR')} pagantes para cobrir custos.`,
      acao: 'Revisar custos e intensificar ações de venda imediatamente.',
    })
  } else if (kpis.publico_atual < kpis.breakeven_publico) {
    alerts.push({
      nivel: 'atencao' as const,
      titulo: 'Break-even não atingido',
      descricao: `Faltam ${(kpis.breakeven_publico - kpis.publico_atual).toLocaleString('pt-BR')} pagantes para cobrir custos.`,
      acao: 'Acelerar vendas e verificar lote atual.',
    })
  }

  // Meta
  if (kpis.meta_atingida_pct < 40) {
    alerts.push({
      nivel: 'critico' as const,
      titulo: 'Evento abaixo da curva',
      descricao: `Meta atingida em apenas ${kpis.meta_atingida_pct.toFixed(0)}%.`,
      acao: 'Revisar estratégia de comunicação e ativar desconto urgente.',
    })
  } else if (kpis.meta_atingida_pct < 70) {
    alerts.push({
      nivel: 'atencao' as const,
      titulo: 'Meta diária não atingida',
      descricao: `${kpis.meta_atingida_pct.toFixed(0)}% da meta realizada.`,
    })
  }

  // ROI
  if (kpis.roi < 0) {
    alerts.push({
      nivel: 'critico' as const,
      titulo: 'ROI negativo',
      descricao: `Resultado projetado de ${kpis.roi.toFixed(0)}% de retorno.`,
      acao: 'Reavaliar viabilidade e reduzir custos.',
    })
  }

  // Days remaining
  if (diasRestantes > 0 && diasRestantes <= 7) {
    alerts.push({
      nivel: 'atencao' as const,
      titulo: `${diasRestantes} dias restantes`,
      descricao: 'Evento próximo. Confirmar operação, equipe e patrocínios.',
    })
  }

  // Healthy signals
  if (kpis.ocupacao_pct >= 80) {
    alerts.push({
      nivel: 'saudavel' as const,
      titulo: 'Ocupação excelente',
      descricao: `${kpis.ocupacao_pct.toFixed(0)}% de ocupação projetada.`,
    })
  }

  if (kpis.roi >= 40) {
    alerts.push({
      nivel: 'saudavel' as const,
      titulo: 'ROI saudável',
      descricao: `Retorno projetado de ${kpis.roi.toFixed(0)}% sobre o investimento.`,
    })
  }

  return alerts
}

// ─── Formatters ───────────────────────────────────────────────────────────────

export function formatCurrency(value: number, compact = false): string {
  if (compact && Math.abs(value) >= 1000) {
    const abs = Math.abs(value)
    const sign = value < 0 ? '-' : ''
    if (abs >= 1_000_000) {
      return `${sign}R$ ${(abs / 1_000_000).toFixed(1)}M`
    }
    return `${sign}R$ ${(abs / 1000).toFixed(abs >= 10000 ? 0 : 1)}k`
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

export function formatPercent(value: number, decimals = 0): string {
  return `${value.toFixed(decimals)}%`
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(Math.round(value))
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  })
}

export function formatDateShort(date: string): string {
  return new Date(date).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'short',
  })
}
