'use client'

import { motion } from 'framer-motion'
import Link from 'next/link'
import { ChevronRight, Clock } from 'lucide-react'
import type { EventCardData } from '@/types'
import { formatCurrency } from '@/lib/calculations'
import HealthBadge from '@/components/shared/HealthBadge'
import HealthRing from '@/components/shared/HealthRing'

const STATUS_COLORS = {
  saudavel: '#4ADE80',
  atencao: '#FACC15',
  critico: '#EF4444',
  realizado: '#8B5CF6',
  aguardando: '#A1A1AA',
  arquivado: '#A1A1AA',
}

interface Props {
  event: EventCardData
  index: number
}

export default function EventRadarCard({ event: ev, index }: Props) {
  const color = STATUS_COLORS[ev.status] ?? '#A1A1AA'
  const isWaiting = ev.status === 'aguardando'

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06, duration: 0.3 }}
      whileHover={{ y: -4 }}
      className="glass overflow-hidden cursor-pointer"
    >
      <Link href={`/eventos/${ev.id}`} className="block">
        {/* Hero image */}
        <div
          className="h-[110px] relative flex items-end p-[11px] bg-cover bg-center"
          style={{
            backgroundImage: ev.imagem_url
              ? `url(${ev.imagem_url})`
              : 'linear-gradient(135deg, #232733, #171A21)',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-lab-bg/95 to-lab-bg/5" />

          <div className="absolute top-2.5 right-2.5">
            <HealthBadge status={ev.status} sm />
          </div>

          <div className="relative">
            <div className="text-[15px] font-extrabold text-lab-ice tracking-[-0.2px]">
              {ev.nome}
            </div>
            <div className="text-[10.5px] text-white/55 flex gap-1.5 mt-0.5">
              <span>{ev.local}</span>
              <span>·</span>
              <span>
                {new Date(ev.data).toLocaleDateString('pt-BR', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
                })}
              </span>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-[12px_14px]">
          {isWaiting ? (
            <p className="text-lab-gray text-[12px] leading-relaxed py-2">
              Aguardando importação ou preenchimento manual.
            </p>
          ) : (
            <>
              {/* Result + ring */}
              <div className="flex justify-between items-center mb-2.5">
                <div>
                  <div className="text-[9.5px] text-lab-gray uppercase tracking-[0.5px]">
                    Resultado projetado
                  </div>
                  <div
                    className="font-mono-nums text-[18px] font-extrabold"
                    style={{
                      color: ev.resultado_projetado >= 0 ? '#4ADE80' : '#EF4444',
                    }}
                  >
                    {formatCurrency(ev.resultado_projetado, true)}
                  </div>
                </div>
                <HealthRing
                  pct={ev.meta_atingida_pct}
                  size={46}
                  color={color}
                  stroke={5}
                  label="meta"
                />
              </div>

              {/* Progress bar */}
              <div className="progress-track mb-2">
                <div
                  className="progress-fill"
                  style={{
                    width: `${Math.min(100, ev.ocupacao_pct)}%`,
                    background: `linear-gradient(90deg, ${color}88, ${color})`,
                  }}
                />
              </div>

              {/* Stats */}
              <div className="flex justify-between text-[10px] text-lab-gray">
                <span className="flex items-center gap-1">
                  <Clock size={10} />
                  {ev.dias_restantes} dias restantes
                </span>
                <span>{Math.round(ev.ocupacao_pct)}% ocupação</span>
              </div>
            </>
          )}
        </div>
      </Link>

      {/* Footer CTA */}
      <Link
        href={`/eventos/${ev.id}`}
        className="flex items-center justify-center gap-1.5 w-full py-[9px] border-t border-white/[0.05] text-lab-gold text-[12px] font-semibold hover:bg-lab-gold/[0.07] transition-colors"
      >
        Abrir evento
        <ChevronRight size={12} strokeWidth={2} />
      </Link>
    </motion.div>
  )
}
