'use client'

import { useEffect, useRef } from 'react'

interface HealthRingProps {
  pct: number
  size?: number
  color?: string
  stroke?: number
  label?: string
}

export default function HealthRing({
  pct,
  size = 46,
  color = '#C7A86B',
  stroke = 4,
  label,
}: HealthRingProps) {
  const circleRef = useRef<SVGCircleElement>(null)
  const r = (size - stroke) / 2
  const circumference = 2 * Math.PI * r
  const v = Math.min(100, Math.max(0, pct || 0))
  const offset = circumference - (circumference * v) / 100

  useEffect(() => {
    if (!circleRef.current) return
    circleRef.current.style.strokeDashoffset = String(circumference)
    const id = requestAnimationFrame(() => {
      setTimeout(() => {
        if (circleRef.current) {
          circleRef.current.style.transition =
            'stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1)'
          circleRef.current.style.strokeDashoffset = String(offset)
        }
      }, 100)
    })
    return () => cancelAnimationFrame(id)
  }, [offset, circumference])

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        style={{ transform: 'rotate(-90deg)' }}
      >
        {/* Track */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="rgba(255,255,255,0.07)"
          strokeWidth={stroke}
        />
        {/* Fill */}
        <circle
          ref={circleRef}
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={circumference}
        />
      </svg>
      {/* Center text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center gap-[1px]">
        <span
          className="font-mono-nums font-bold text-lab-ice"
          style={{ fontSize: size > 46 ? 13 : 10 }}
        >
          {Math.round(v)}%
        </span>
        {label && (
          <span className="text-[8px] text-lab-gray">{label}</span>
        )}
      </div>
    </div>
  )
}
