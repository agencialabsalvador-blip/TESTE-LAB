import { CheckCircle2, AlertTriangle, Flame, Clock, CheckSquare } from 'lucide-react'
import type { EventStatus } from '@/types'
import { cn } from '@/lib/utils'

const STATUS_CONFIG = {
  saudavel:  { label: 'Saudável',          Icon: CheckCircle2, cls: 'lab-badge-green'  },
  atencao:   { label: 'Atenção',           Icon: AlertTriangle, cls: 'lab-badge-yellow' },
  critico:   { label: 'Crítico',           Icon: Flame,         cls: 'lab-badge-red'    },
  realizado: { label: 'Realizado',         Icon: CheckSquare,   cls: 'lab-badge-purple' },
  aguardando:{ label: 'Aguardando Dados',  Icon: Clock,         cls: 'lab-badge-gray'   },
  arquivado: { label: 'Arquivado',         Icon: Clock,         cls: 'lab-badge-gray'   },
}

interface HealthBadgeProps {
  status: EventStatus
  sm?: boolean
}

export default function HealthBadge({ status, sm }: HealthBadgeProps) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.aguardando
  const { label, Icon, cls } = cfg

  return (
    <span className={cn(cls, sm && 'text-[10px] py-0.5 px-2')}>
      <Icon size={sm ? 10 : 12} />
      {label}
    </span>
  )
}
