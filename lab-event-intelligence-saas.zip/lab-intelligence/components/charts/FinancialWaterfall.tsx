'use client'

import { useEffect, useRef, useState } from 'react'
import { formatCurrency } from '@/lib/calculations'

interface WaterfallStep {
  label: string
  value: number
  type: 'in' | 'out' | 'result'
  color: string
}

interface Props {
  bilheteria: number
  bar: number
  patrocinio: number
  outros: number
  custos: number
  title?: string
}

export default function FinancialWaterfall({
  bilheteria, bar, patrocinio, outros, custos, title = 'Economia do Evento',
}: Props) {
  const resultado = bilheteria + bar + patrocinio + outros - custos
  const [animated, setAnimated] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setAnimated(true) },
      { threshold: 0.2 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [])

  const steps: WaterfallStep[] = [
    { label: '🎟 Bilheteria',  value: bilheteria,  type: 'in',     color: '#C7A86B' },
    { label: '🍹 Bar A&B',    value: bar,          type: 'in',     color: '#8B5CF6' },
    { label: '🤝 Patrocínios', value: patrocinio,  type: 'in',     color: '#FACC15' },
    { label: '💰 Outros',     value: outros,       type: 'in',     color: '#4ADE80' },
    { label: '🧾 Custos',     value: -custos,      type: 'out',    color: '#EF4444' },
    { label: '📈 Resultado',  value: resultado,    type: 'result', color: resultado >= 0 ? '#4ADE80' : '#EF4444' },
  ]

  const receita = bilheteria + bar + patrocinio + outros
  const max = receita || 1

  let running = 0

  return (
    <div ref={ref} className="glass p-5">
      <h3 className="text-[14px] font-bold text-lab-ice mb-1">{title}</h3>
      <p className="text-[11px] text-lab-gray mb-5">
        Composição financeira · cenário atual
      </p>

      <div className="flex flex-col gap-2.5">
        {steps.map((step, i) => {
          const isResult = step.type === 'result'
          const base = isResult ? 0 : step.type === 'out' ? running + step.value : running
          const widthPct = Math.min(100, (Math.abs(step.value) / max) * 100)
          const offsetPct = isResult ? 0 : (Math.max(0, base) / max) * 100

          if (step.type === 'in') running += step.value
          if (step.type === 'out') running += step.value

          return (
            <div key={step.label}>
              <div className="flex justify-between text-[11.5px] mb-1">
                <span className="text-lab-ice font-medium">{step.label}</span>
                <span
                  className="font-mono-nums font-bold"
                  style={{ color: step.color }}
                >
                  {step.value < 0 ? '−' : ''}
                  {formatCurrency(Math.abs(step.value), true)}
                </span>
              </div>
              <div className="relative h-[12px] bg-white/[0.04] rounded-[4px] overflow-hidden">
                <div
                  className="absolute top-0 h-full rounded-[4px] transition-all duration-1000 ease-out"
                  style={{
                    width: animated ? `${widthPct}%` : '0%',
                    left: `${offsetPct}%`,
                    background: `${step.color}bb`,
                    border: isResult ? `1px solid ${step.color}` : undefined,
                    transitionDelay: `${i * 0.1}s`,
                  }}
                />
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
