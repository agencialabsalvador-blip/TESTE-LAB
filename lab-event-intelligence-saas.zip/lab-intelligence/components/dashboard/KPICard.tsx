'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import HealthRing from '@/components/shared/HealthRing'

interface KPICardProps {
  label: string
  value: string
  sub?: string
  icon: React.ReactNode
  color: string
  hero?: boolean
  ring?: number
  delay?: number
  className?: string
}

export default function KPICard({
  label, value, sub, icon, color, hero, ring, delay = 0, className,
}: KPICardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.3 }}
    >
      <div
        className={cn(
          'glass p-[18px] relative overflow-hidden',
          hero && 'border-lab-gold/30',
          className
        )}
      >
        {hero && (
          <div
            className="absolute -top-10 -right-10 w-32 h-32 rounded-full pointer-events-none"
            style={{
              background: `radial-gradient(${color}22, transparent 70%)`,
            }}
          />
        )}

        <div className="flex justify-between items-start">
          {/* Icon */}
          <div
            className="w-[30px] h-[30px] rounded-[9px] flex items-center justify-center mb-3"
            style={{ background: `${color}1A`, color }}
          >
            {icon}
          </div>

          {/* Ring (optional) */}
          {ring != null && (
            <HealthRing pct={ring} size={42} color={color} stroke={4} label="saúde" />
          )}
        </div>

        <div className="text-[9.5px] text-lab-gray font-semibold tracking-[0.5px] uppercase">
          {label}
        </div>
        <div
          className={cn(
            'font-mono-nums font-extrabold text-lab-ice tracking-tight mt-1',
            hero ? 'text-[26px]' : 'text-[21px]'
          )}
          style={{ color: hero ? color : undefined }}
        >
          {value}
        </div>
        {sub && (
          <div className="text-[11px] text-lab-gray mt-0.5">{sub}</div>
        )}
      </div>
    </motion.div>
  )
}
