# LAB Event Intelligence — SaaS

> Central de inteligência e viabilidade para eventos de entretenimento.

## Stack

| Camada | Tecnologia |
|--------|-----------|
| Frontend | Next.js 15 + TypeScript + TailwindCSS |
| UI | Shadcn UI + Framer Motion + Lucide Icons |
| Gráficos | Recharts |
| Formulários | React Hook Form + Zod |
| Backend | Supabase (PostgreSQL + Auth + Storage + Realtime) |
| Deploy | Vercel |

## Estrutura do Projeto

```
lab-intelligence/
├── app/
│   ├── auth/               # Login, Cadastro, Esqueci Senha
│   ├── dashboard/          # Dashboard principal
│   ├── eventos/            # CRUD de eventos
│   │   ├── [id]/           # Detalhe do evento
│   │   │   ├── financeiro/
│   │   │   ├── cenarios/
│   │   │   ├── decisao/
│   │   │   ├── alertas/
│   │   │   ├── volumetria/
│   │   │   └── importacoes/
│   │   └── novo/
│   ├── admin/              # Painel administrativo
│   │   ├── empresa/
│   │   ├── usuarios/
│   │   ├── permissoes/
│   │   ├── integracoes/
│   │   ├── configuracoes/  # Tudo editável sem código
│   │   └── logs/
│   └── api/                # API Routes
├── components/
│   ├── dashboard/          # KPICard, ExecutiveSummary
│   ├── events/             # EventRadarCard, EventDetail
│   ├── charts/             # FinancialWaterfall, ScenarioChart
│   ├── financial/          # CostForm, SponsorList, BarModule
│   ├── forms/              # Formulários reutilizáveis
│   ├── shared/             # HealthBadge, HealthRing, etc
│   └── layout/             # Sidebar, Header
├── contexts/               # AuthContext
├── hooks/                  # useEvent, useKPIs, etc
├── lib/
│   ├── calculations.ts     # Fórmulas financeiras
│   ├── validations.ts      # Schemas Zod
│   ├── utils.ts            # Helpers
│   └── supabase/           # Client e Server clients
├── services/               # API calls (events, import, etc)
├── supabase/
│   ├── migrations/         # Schema SQL completo
│   └── config.toml
└── types/                  # TypeScript types
```

## Setup Rápido

### 1. Clonar e instalar

```bash
git clone https://github.com/seu-usuario/lab-intelligence
cd lab-intelligence
npm install
```

### 2. Configurar Supabase

1. Criar projeto em [supabase.com](https://supabase.com)
2. Copiar `.env.local.example` para `.env.local`
3. Preencher `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY`

### 3. Rodar migrations

```bash
# Instalar CLI Supabase
npm install -g supabase

# Iniciar Supabase local (opcional)
supabase start

# Aplicar schema no projeto remoto
supabase db push --project-ref SEU_PROJECT_REF
```

Ou cole o conteúdo de `supabase/migrations/001_initial_schema.sql`
diretamente no **SQL Editor** do Supabase Dashboard.

### 4. Criar primeiro usuário e empresa

No SQL Editor do Supabase:

```sql
-- 1. Crie a empresa
INSERT INTO companies (nome, slug, cor_primaria) 
VALUES ('LAB Entretenimento', 'lab-entretenimento', '#C7A86B')
RETURNING id;

-- 2. Inicializar configurações padrão
SELECT init_company_settings('ID_DA_EMPRESA_AQUI');
```

Depois crie um usuário via Auth > Users no Supabase Dashboard
e insira na tabela `users`:

```sql
INSERT INTO users (id, empresa_id, nome, email, perfil)
VALUES ('UUID_DO_AUTH_USER', 'UUID_DA_EMPRESA', 'Seu Nome', 'seu@email.com', 'admin');
```

### 5. Rodar em desenvolvimento

```bash
npm run dev
```

Acesse: `http://localhost:3000`

---

## Deploy na Vercel

```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Deploy
vercel

# 3. Configurar variáveis de ambiente no dashboard da Vercel:
#    NEXT_PUBLIC_SUPABASE_URL
#    NEXT_PUBLIC_SUPABASE_ANON_KEY
```

---

## Perfis de Acesso

| Perfil | Permissões |
|--------|-----------|
| **admin** | Acesso total + painel administrativo |
| **financeiro** | Editar dados financeiros, custos, patrocínios |
| **producao** | Criar/editar eventos, importar dados |
| **marketing** | Visualizar + criar notas |
| **visualizacao** | Somente leitura |

---

## Fórmulas Financeiras

```
Receita Bar = Público × Ticket Médio A&B × Participação LAB
Valor Econômico = Bilheteria + Bar + Patrocínios + Outras Receitas
Resultado = Receita Total − Custos
Margem = Resultado ÷ Receita Total × 100
ROI = Resultado ÷ Custos × 100
Break-even = Custos ÷ (Ticket Ingresso + Ticket A&B × % LAB)
```

---

## Configurações Editáveis (sem código)

Todas as configurações são editáveis via **Painel Admin > Configurações**:

- Título do dashboard
- Slogan
- Ticket médio padrão de A&B
- Participação % no bar
- Cores da marca
- Fuso horário
- Modo demonstração (dados simulados)

---

## Variáveis de Ambiente

| Variável | Descrição |
|----------|-----------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL do projeto Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Chave anônima Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Chave de serviço (só servidor) |
| `NEXT_PUBLIC_APP_URL` | URL da aplicação |

---

## Modo Demonstração

Para exibir dados simulados, altere no painel admin:

```
Configurações > Sistema > mostrar_demo = true
```

---

## Suporte

Projeto LAB Entretenimento · Salvador · BA
