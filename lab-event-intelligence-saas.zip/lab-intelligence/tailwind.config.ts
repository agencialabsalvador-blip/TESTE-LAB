import type { Config } from 'tailwindcss'
import { fontFamily } from 'tailwindcss/defaultTheme'

const config: Config = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '2rem',
      screens: { '2xl': '1400px' },
    },
    extend: {
      colors: {
        // LAB Brand Tokens
        lab: {
          bg: '#0F1117',
          graphite: '#171A21',
          graphiteL: '#232733',
          ice: '#F5F5F0',
          gray: '#A1A1AA',
          gold: '#C7A86B',
          green: '#4ADE80',
          yellow: '#FACC15',
          red: '#EF4444',
          purple: '#8B5CF6',
          pink: '#EC4899',
        },
        // Shadcn tokens mapped to LAB
        border: 'rgba(255,255,255,0.06)',
        input: 'rgba(255,255,255,0.06)',
        ring: '#C7A86B',
        background: '#0F1117',
        foreground: '#F5F5F0',
        primary: {
          DEFAULT: '#C7A86B',
          foreground: '#0F1117',
        },
        secondary: {
          DEFAULT: '#232733',
          foreground: '#F5F5F0',
        },
        destructive: {
          DEFAULT: '#EF4444',
          foreground: '#F5F5F0',
        },
        muted: {
          DEFAULT: '#171A21',
          foreground: '#A1A1AA',
        },
        accent: {
          DEFAULT: '#232733',
          foreground: '#F5F5F0',
        },
        popover: {
          DEFAULT: '#171A21',
          foreground: '#F5F5F0',
        },
        card: {
          DEFAULT: '#171A21',
          foreground: '#F5F5F0',
        },
      },
      borderRadius: {
        lg: '14px',
        md: '10px',
        sm: '7px',
      },
      fontFamily: {
        sans: ['Inter', ...fontFamily.sans],
        mono: ['JetBrains Mono', ...fontFamily.mono],
      },
      backgroundImage: {
        'glass': 'linear-gradient(160deg, rgba(35,39,51,0.58), rgba(23,26,33,0.70))',
        'gold-gradient': 'linear-gradient(135deg, #C7A86B, #8a7340)',
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'pulse-dot': 'pulse-dot 2s infinite',
        'fade-in': 'fade-in 0.2s ease-out',
        'slide-up': 'slide-up 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      },
      keyframes: {
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        'pulse-dot': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.4' },
        },
        'fade-in': {
          from: { opacity: '0', transform: 'translateY(5px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-up': {
          from: { opacity: '0', transform: 'translateY(12px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [require('tailwindcss-animate')],
}

export default config
