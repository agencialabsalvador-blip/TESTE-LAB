// ─── Enums ───────────────────────────────────────────────────────────────────

export type EventStatus = 'saudavel' | 'atencao' | 'critico' | 'realizado' | 'aguardando' | 'arquivado'
export type UserRole = 'admin' | 'financeiro' | 'producao' | 'marketing' | 'visualizacao'
export type SponsorStatus = 'confirmado' | 'pendente' | 'negociando' | 'cancelado'
export type SaleStatus = 'confirmado' | 'cancelado' | 'aguardando'
export type ImportPlatform = 'bilheteria_digital' | 'sympla' | 'ingresse' | 'shotgun' | 'zig' | 'google_sheets' | 'csv' | 'excel'
export type AlertLevel = 'saudavel' | 'atencao' | 'critico'
export type ScenarioType = 'conservador' | 'realista' | 'agressivo'

// ─── Company ─────────────────────────────────────────────────────────────────

export interface Company {
  id: string
  nome: string
  slug: string
  logo_url?: string
  cor_primaria: string
  cor_secundaria: string
  ticket_medio_ab: number
  participacao_bar: number
  configuracoes: CompanySettings
  created_at: string
  updated_at: string
}

export interface CompanySettings {
  titulo_dashboard: string
  slogan: string
  categorias_custo: CostCategory[]
  categorias_receita: string[]
  mostrar_demo: boolean
  timezone: string
}

export interface CostCategory {
  id: string
  label: string
  icon?: string
  ordem: number
}

// ─── User ─────────────────────────────────────────────────────────────────────

export interface User {
  id: string
  empresa_id: string
  nome: string
  email: string
  cargo?: string
  perfil: UserRole
  foto_url?: string
  ativo: boolean
  created_at: string
  updated_at: string
}

// ─── Event ────────────────────────────────────────────────────────────────────

export interface Event {
  id: string
  empresa_id: string
  nome: string
  slug: string
  data: string
  cidade: string
  local: string
  capacidade: number
  status: EventStatus
  imagem_url?: string
  observacoes?: string
  created_at: string
  updated_at: string
  // Relations
  settings?: EventSettings
  costs?: EventCosts
  sponsors?: Sponsor[]
  bar_settings?: BarSettings
  scenarios?: Scenario[]
  kpis?: EventKPIs
}

export interface EventSettings {
  id: string
  evento_id: string
  ticket_medio_ingresso: number
  ticket_medio_ab: number
  participacao_lab: number
  meta_receita: number
  meta_publico: number
  publico_conservador: number
  publico_realista: number
  publico_agressivo: number
  publico_atual: number
  cortesias: number
  imposto_bilheteria: number
}

export interface EventCosts {
  id: string
  evento_id: string
  artistico: number
  estrutura: number
  marketing: number
  producao: number
  equipe: number
  operacao: number
  impostos: number
  outros: number
  // computed
  total?: number
}

// ─── Sponsors ────────────────────────────────────────────────────────────────

export interface Sponsor {
  id: string
  evento_id: string
  empresa: string
  valor: number
  status: SponsorStatus
  data_confirmacao?: string
  observacoes?: string
  created_at: string
}

// ─── Sales ───────────────────────────────────────────────────────────────────

export interface Sale {
  id: string
  evento_id: string
  empresa_id: string
  cliente?: string
  data: string
  hora?: string
  lote: string
  quantidade: number
  valor_bruto: number
  taxa: number
  valor_liquido: number
  plataforma: ImportPlatform
  canal?: string
  cupom?: string
  status: SaleStatus
  created_at: string
}

export interface SalesSummary {
  total_ingressos: number
  valor_bruto: number
  valor_liquido: number
  ticket_medio: number
  por_lote: LoteSummary[]
  por_plataforma: PlataformaSummary[]
  historico_diario: DailySales[]
}

export interface LoteSummary {
  lote: string
  quantidade: number
  valor_total: number
  ticket_medio: number
}

export interface PlataformaSummary {
  plataforma: string
  quantidade: number
  valor_total: number
}

export interface DailySales {
  data: string
  ingressos: number
  receita: number
}

// ─── Bar ─────────────────────────────────────────────────────────────────────

export interface BarSettings {
  id: string
  evento_id: string
  ticket_medio: number
  participacao_empresa: number
}

export interface BarSales {
  id: string
  evento_id: string
  data: string
  faturamento_bruto: number
  receita_empresa: number
  observacoes?: string
}

// ─── Scenarios ───────────────────────────────────────────────────────────────

export interface Scenario {
  id: string
  evento_id: string
  tipo: ScenarioType
  publico: number
  bilheteria: number
  bar: number
  patrocinio: number
  outras_receitas: number
  receita_total: number
  custos: number
  resultado: number
  margem: number
  roi: number
  risco: AlertLevel
  recomendacao: string
}

// ─── Financial KPIs ──────────────────────────────────────────────────────────

export interface EventKPIs {
  // Revenue
  bilheteria_bruta: number
  bilheteria_liquida: number
  receita_bar: number
  receita_patrocinios: number
  outras_receitas: number
  valor_economico_total: number
  receita_realizada: number
  // Costs
  custo_total: number
  // Results
  resultado_projetado: number
  resultado_realizado: number
  margem: number
  roi: number
  // Tickets
  ticket_medio_ingresso: number
  ticket_medio_ab: number
  // Audience
  publico_atual: number
  publico_projetado: number
  capacidade: number
  ocupacao_pct: number
  // Goals
  meta_receita: number
  meta_atingida_pct: number
  breakeven_publico: number
  // Sales velocity
  dias_restantes: number
  velocidade_vendas: number // ingressos/dia
  meta_diaria: number
  projecao_sold_out?: string
}

// ─── Alerts ──────────────────────────────────────────────────────────────────

export interface Alert {
  id: string
  evento_id: string
  nivel: AlertLevel
  titulo: string
  descricao: string
  acao?: string
  ativo: boolean
  created_at: string
}

// ─── Decision Center ─────────────────────────────────────────────────────────

export interface Decision {
  evento_id: string
  evento_nome: string
  status: EventStatus
  diagnostico: string
  risco_principal: string
  oportunidade_principal: string
  acao_24h: string
  acao_7dias: string
  necessidades: DecisionNeed[]
}

export interface DecisionNeed {
  tipo: 'midia' | 'patrocinio' | 'custo' | 'lote' | 'comunicacao'
  descricao: string
  valor?: number
}

// ─── Import ──────────────────────────────────────────────────────────────────

export interface ImportJob {
  id: string
  evento_id: string
  plataforma: ImportPlatform
  arquivo?: string
  status: 'processando' | 'concluido' | 'erro'
  total_registros: number
  registros_importados: number
  erros: ImportError[]
  created_at: string
}

export interface ImportError {
  linha: number
  campo: string
  mensagem: string
}

export interface ImportRow {
  cliente?: string
  evento?: string
  lote: string
  quantidade: number
  valor_bruto: number
  taxa: number
  valor_liquido: number
  canal?: string
  cupom?: string
  status: string
  plataforma: string
  data: string
  hora?: string
}

// ─── System Settings ─────────────────────────────────────────────────────────

export interface SystemSettings {
  id: string
  empresa_id: string
  chave: string
  valor: string
  tipo: 'string' | 'number' | 'boolean' | 'json' | 'color'
  descricao?: string
  grupo: string
  updated_at: string
}

// ─── Dashboard Summary ────────────────────────────────────────────────────────

export interface DashboardSummary {
  valor_economico_total: number
  receita_realizada: number
  resultado_projetado: number
  saude_geral: number
  total_eventos_ativos: number
  eventos: EventCardData[]
}

export interface EventCardData {
  id: string
  nome: string
  emoji?: string
  data: string
  cidade: string
  local: string
  capacidade: number
  publico_atual: number
  status: EventStatus
  imagem_url?: string
  resultado_projetado: number
  meta_atingida_pct: number
  dias_restantes: number
  ocupacao_pct: number
  valor_economico: number
  patrocinio_total: number
}

// ─── API Response ─────────────────────────────────────────────────────────────

export interface ApiResponse<T> {
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  total: number
  page: number
  per_page: number
}

// ─── Form Types ───────────────────────────────────────────────────────────────

export interface CreateEventForm {
  nome: string
  data: string
  cidade: string
  local: string
  capacidade: number
  ticket_medio_ingresso: number
  ticket_medio_ab: number
  participacao_lab: number
  meta_receita: number
  meta_publico: number
  publico_conservador: number
  publico_realista: number
  publico_agressivo: number
}

export interface CreateSponsorForm {
  empresa: string
  valor: number
  status: SponsorStatus
  observacoes?: string
}

export interface CreateCostForm {
  artistico: number
  estrutura: number
  marketing: number
  producao: number
  equipe: number
  operacao: number
  impostos: number
  outros: number
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string
  email: string
  user_metadata: {
    nome?: string
    empresa_id?: string
  }
}

export interface Session {
  user: AuthUser
  access_token: string
  refresh_token: string
}
