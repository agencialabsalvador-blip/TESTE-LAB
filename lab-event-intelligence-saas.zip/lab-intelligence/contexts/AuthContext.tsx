'use client'

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react'
import type { User as SupabaseUser } from '@supabase/supabase-js'
import { createClient } from '@/lib/supabase/client'
import type { User, Company } from '@/types'

interface AuthContextValue {
  supabaseUser: SupabaseUser | null
  user: User | null
  company: Company | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<{ error?: string }>
  signOut: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const supabase = createClient()
  const [supabaseUser, setSupabaseUser] = useState<SupabaseUser | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [company, setCompany] = useState<Company | null>(null)
  const [loading, setLoading] = useState(true)

  const loadUserData = useCallback(
    async (supaUser: SupabaseUser) => {
      const { data: userData } = await supabase
        .from('users')
        .select('*, companies(*)')
        .eq('id', supaUser.id)
        .single()

      if (userData) {
        const { companies: companyData, ...rest } = userData as User & {
          companies: Company
        }
        setUser(rest)
        setCompany(companyData)
      }
    },
    [supabase]
  )

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSupabaseUser(session?.user ?? null)
      if (session?.user) {
        loadUserData(session.user).finally(() => setLoading(false))
      } else {
        setLoading(false)
      }
    })

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSupabaseUser(session?.user ?? null)
      if (session?.user) {
        loadUserData(session.user)
      } else {
        setUser(null)
        setCompany(null)
      }
    })

    return () => subscription.unsubscribe()
  }, [loadUserData, supabase.auth])

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })
    if (error) return { error: error.message }
    return {}
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setCompany(null)
  }

  const refreshUser = async () => {
    if (supabaseUser) await loadUserData(supabaseUser)
  }

  return (
    <AuthContext.Provider
      value={{
        supabaseUser,
        user,
        company,
        loading,
        signIn,
        signOut,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
