-- ============================================================
-- LAB Event Intelligence — Database Schema
-- Migration: 001_initial_schema
-- ============================================================

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ─── ENUMS ────────────────────────────────────────────────────

CREATE TYPE event_status AS ENUM (
  'aguardando', 'saudavel', 'atencao', 'critico', 'realizado', 'arquivado'
);

CREATE TYPE user_role AS ENUM (
  'admin', 'financeiro', 'producao', 'marketing', 'visualizacao'
);

CREATE TYPE sponsor_status AS ENUM (
  'confirmado', 'pendente', 'negociando', 'cancelado'
);

CREATE TYPE sale_status AS ENUM (
  'confirmado', 'cancelado', 'aguardando'
);

CREATE TYPE import_platform AS ENUM (
  'bilheteria_digital', 'sympla', 'ingresse', 'shotgun',
  'zig', 'google_sheets', 'csv', 'excel'
);

CREATE TYPE alert_level AS ENUM ('saudavel', 'atencao', 'critico');

CREATE TYPE scenario_type AS ENUM ('conservador', 'realista', 'agressivo');

CREATE TYPE setting_type AS ENUM ('string', 'number', 'boolean', 'json', 'color');

-- ─── COMPANIES ────────────────────────────────────────────────

CREATE TABLE companies (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  nome          TEXT NOT NULL,
  slug          TEXT UNIQUE NOT NULL,
  logo_url      TEXT,
  cor_primaria  TEXT NOT NULL DEFAULT '#C7A86B',
  cor_secundaria TEXT NOT NULL DEFAULT '#8B5CF6',
  ticket_medio_ab    NUMERIC(10,2) NOT NULL DEFAULT 100.00,
  participacao_bar   NUMERIC(5,4)  NOT NULL DEFAULT 0.5000,
  configuracoes      JSONB NOT NULL DEFAULT '{}',
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── USERS ────────────────────────────────────────────────────

CREATE TABLE users (
  id          UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  empresa_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  nome        TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE,
  cargo       TEXT,
  perfil      user_role NOT NULL DEFAULT 'visualizacao',
  foto_url    TEXT,
  ativo       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── EVENTS ───────────────────────────────────────────────────

CREATE TABLE events (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  empresa_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  nome        TEXT NOT NULL,
  slug        TEXT NOT NULL,
  data        DATE NOT NULL,
  cidade      TEXT NOT NULL,
  local       TEXT NOT NULL,
  capacidade  INTEGER NOT NULL DEFAULT 0,
  status      event_status NOT NULL DEFAULT 'aguardando',
  imagem_url  TEXT,
  observacoes TEXT,
  created_by  UUID REFERENCES users(id),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(empresa_id, slug)
);

CREATE INDEX idx_events_empresa ON events(empresa_id);
CREATE INDEX idx_events_data ON events(data);
CREATE INDEX idx_events_status ON events(status);

-- ─── EVENT SETTINGS ───────────────────────────────────────────

CREATE TABLE event_settings (
  id                     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id              UUID NOT NULL UNIQUE REFERENCES events(id) ON DELETE CASCADE,
  ticket_medio_ingresso  NUMERIC(10,2) NOT NULL DEFAULT 0,
  ticket_medio_ab        NUMERIC(10,2) NOT NULL DEFAULT 100,
  participacao_lab       NUMERIC(5,4)  NOT NULL DEFAULT 0.5,
  meta_receita           NUMERIC(15,2) NOT NULL DEFAULT 0,
  meta_publico           INTEGER NOT NULL DEFAULT 0,
  publico_conservador    INTEGER NOT NULL DEFAULT 0,
  publico_realista       INTEGER NOT NULL DEFAULT 0,
  publico_agressivo      INTEGER NOT NULL DEFAULT 0,
  publico_atual          INTEGER NOT NULL DEFAULT 0,
  cortesias              INTEGER NOT NULL DEFAULT 0,
  imposto_bilheteria     NUMERIC(5,4) NOT NULL DEFAULT 0.08,
  created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── COSTS ────────────────────────────────────────────────────

CREATE TABLE costs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id   UUID NOT NULL UNIQUE REFERENCES events(id) ON DELETE CASCADE,
  artistico   NUMERIC(15,2) NOT NULL DEFAULT 0,
  estrutura   NUMERIC(15,2) NOT NULL DEFAULT 0,
  marketing   NUMERIC(15,2) NOT NULL DEFAULT 0,
  producao    NUMERIC(15,2) NOT NULL DEFAULT 0,
  equipe      NUMERIC(15,2) NOT NULL DEFAULT 0,
  operacao    NUMERIC(15,2) NOT NULL DEFAULT 0,
  impostos    NUMERIC(15,2) NOT NULL DEFAULT 0,
  outros      NUMERIC(15,2) NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Computed total via function
CREATE OR REPLACE FUNCTION costs_total(c costs) RETURNS NUMERIC AS $$
  SELECT c.artistico + c.estrutura + c.marketing + c.producao +
         c.equipe + c.operacao + c.impostos + c.outros;
$$ LANGUAGE sql IMMUTABLE;

-- ─── SPONSORS ─────────────────────────────────────────────────

CREATE TABLE sponsors (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id         UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  empresa           TEXT NOT NULL,
  valor             NUMERIC(15,2) NOT NULL DEFAULT 0,
  status            sponsor_status NOT NULL DEFAULT 'pendente',
  data_confirmacao  DATE,
  observacoes       TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sponsors_evento ON sponsors(evento_id);
CREATE INDEX idx_sponsors_status ON sponsors(status);

-- ─── SALES ────────────────────────────────────────────────────

CREATE TABLE sales (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id      UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  empresa_id     UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  cliente        TEXT,
  data           DATE NOT NULL,
  hora           TIME,
  lote           TEXT NOT NULL,
  quantidade     INTEGER NOT NULL DEFAULT 1,
  valor_bruto    NUMERIC(15,2) NOT NULL DEFAULT 0,
  taxa           NUMERIC(15,2) NOT NULL DEFAULT 0,
  valor_liquido  NUMERIC(15,2) NOT NULL DEFAULT 0,
  plataforma     import_platform NOT NULL,
  canal          TEXT,
  cupom          TEXT,
  status         sale_status NOT NULL DEFAULT 'confirmado',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_sales_evento ON sales(evento_id);
CREATE INDEX idx_sales_data ON sales(data);
CREATE INDEX idx_sales_plataforma ON sales(plataforma);
CREATE INDEX idx_sales_lote ON sales(lote);

-- ─── BAR SETTINGS ─────────────────────────────────────────────

CREATE TABLE bar_settings (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id             UUID NOT NULL UNIQUE REFERENCES events(id) ON DELETE CASCADE,
  ticket_medio          NUMERIC(10,2) NOT NULL DEFAULT 100,
  participacao_empresa  NUMERIC(5,4)  NOT NULL DEFAULT 0.5,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── BAR SALES ────────────────────────────────────────────────

CREATE TABLE bar_sales (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id         UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  data              DATE NOT NULL,
  faturamento_bruto NUMERIC(15,2) NOT NULL DEFAULT 0,
  receita_empresa   NUMERIC(15,2) NOT NULL DEFAULT 0,
  observacoes       TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_bar_sales_evento ON bar_sales(evento_id);

-- ─── SCENARIOS ────────────────────────────────────────────────

CREATE TABLE scenarios (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id        UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  tipo             scenario_type NOT NULL,
  publico          INTEGER NOT NULL DEFAULT 0,
  bilheteria       NUMERIC(15,2) NOT NULL DEFAULT 0,
  bar              NUMERIC(15,2) NOT NULL DEFAULT 0,
  patrocinio       NUMERIC(15,2) NOT NULL DEFAULT 0,
  outras_receitas  NUMERIC(15,2) NOT NULL DEFAULT 0,
  receita_total    NUMERIC(15,2) GENERATED ALWAYS AS (bilheteria + bar + patrocinio + outras_receitas) STORED,
  custos           NUMERIC(15,2) NOT NULL DEFAULT 0,
  resultado        NUMERIC(15,2) GENERATED ALWAYS AS (bilheteria + bar + patrocinio + outras_receitas - custos) STORED,
  margem           NUMERIC(8,4) NOT NULL DEFAULT 0,
  roi              NUMERIC(8,4) NOT NULL DEFAULT 0,
  risco            alert_level NOT NULL DEFAULT 'atencao',
  recomendacao     TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(evento_id, tipo)
);

-- ─── ALERTS ───────────────────────────────────────────────────

CREATE TABLE alerts (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id   UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  nivel       alert_level NOT NULL,
  titulo      TEXT NOT NULL,
  descricao   TEXT NOT NULL,
  acao        TEXT,
  ativo       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_alerts_evento ON alerts(evento_id);
CREATE INDEX idx_alerts_nivel ON alerts(nivel);

-- ─── IMPORT JOBS ──────────────────────────────────────────────

CREATE TABLE import_jobs (
  id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id            UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  empresa_id           UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  plataforma           import_platform NOT NULL,
  arquivo              TEXT,
  status               TEXT NOT NULL DEFAULT 'processando',
  total_registros      INTEGER NOT NULL DEFAULT 0,
  registros_importados INTEGER NOT NULL DEFAULT 0,
  erros                JSONB NOT NULL DEFAULT '[]',
  created_by           UUID REFERENCES users(id),
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── NOTES ────────────────────────────────────────────────────

CREATE TABLE notes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  evento_id   UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  autor_id    UUID NOT NULL REFERENCES users(id),
  conteudo    TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── SYSTEM SETTINGS ──────────────────────────────────────────

CREATE TABLE system_settings (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  empresa_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  chave       TEXT NOT NULL,
  valor       TEXT NOT NULL,
  tipo        setting_type NOT NULL DEFAULT 'string',
  descricao   TEXT,
  grupo       TEXT NOT NULL DEFAULT 'geral',
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(empresa_id, chave)
);

CREATE INDEX idx_settings_empresa ON system_settings(empresa_id);
CREATE INDEX idx_settings_grupo ON system_settings(grupo);

-- ─── AUDIT LOG ────────────────────────────────────────────────

CREATE TABLE audit_logs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  empresa_id  UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  usuario_id  UUID REFERENCES users(id),
  acao        TEXT NOT NULL,
  tabela      TEXT,
  registro_id UUID,
  dados_antes JSONB,
  dados_depois JSONB,
  ip          TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_empresa ON audit_logs(empresa_id);
CREATE INDEX idx_audit_created ON audit_logs(created_at DESC);

-- ─── UPDATED_AT TRIGGERS ──────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_companies_updated_at   BEFORE UPDATE ON companies   FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_users_updated_at       BEFORE UPDATE ON users       FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_events_updated_at      BEFORE UPDATE ON events      FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_settings_updated_at    BEFORE UPDATE ON event_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_costs_updated_at       BEFORE UPDATE ON costs       FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_bar_settings_updated   BEFORE UPDATE ON bar_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_scenarios_updated_at   BEFORE UPDATE ON scenarios   FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_sys_settings_updated   BEFORE UPDATE ON system_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── ROW LEVEL SECURITY ───────────────────────────────────────

ALTER TABLE companies       ENABLE ROW LEVEL SECURITY;
ALTER TABLE users           ENABLE ROW LEVEL SECURITY;
ALTER TABLE events          ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_settings  ENABLE ROW LEVEL SECURITY;
ALTER TABLE costs           ENABLE ROW LEVEL SECURITY;
ALTER TABLE sponsors        ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales           ENABLE ROW LEVEL SECURITY;
ALTER TABLE bar_settings    ENABLE ROW LEVEL SECURITY;
ALTER TABLE bar_sales       ENABLE ROW LEVEL SECURITY;
ALTER TABLE scenarios       ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts          ENABLE ROW LEVEL SECURITY;
ALTER TABLE import_jobs     ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes           ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs      ENABLE ROW LEVEL SECURITY;

-- Helper function: get current user's empresa_id
CREATE OR REPLACE FUNCTION auth_empresa_id() RETURNS UUID AS $$
  SELECT empresa_id FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper function: get current user's role
CREATE OR REPLACE FUNCTION auth_user_role() RETURNS user_role AS $$
  SELECT perfil FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Companies RLS
CREATE POLICY "Users see their own company"
  ON companies FOR SELECT USING (id = auth_empresa_id());

CREATE POLICY "Admins update their company"
  ON companies FOR UPDATE USING (id = auth_empresa_id() AND auth_user_role() = 'admin');

-- Users RLS
CREATE POLICY "Users see users in their company"
  ON users FOR SELECT USING (empresa_id = auth_empresa_id());

CREATE POLICY "Admins manage users in their company"
  ON users FOR ALL USING (empresa_id = auth_empresa_id() AND auth_user_role() = 'admin');

-- Events RLS (all roles in same company can read)
CREATE POLICY "Users see events in their company"
  ON events FOR SELECT USING (empresa_id = auth_empresa_id());

CREATE POLICY "Admin/Producao/Financeiro manage events"
  ON events FOR ALL USING (
    empresa_id = auth_empresa_id() AND
    auth_user_role() IN ('admin', 'producao', 'financeiro')
  );

-- Event data RLS (generic — same empresa via event)
CREATE POLICY "Users see event settings in their company"
  ON event_settings FOR SELECT
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id()));

CREATE POLICY "Financeiro/Admin manage event settings"
  ON event_settings FOR ALL
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id())
    AND auth_user_role() IN ('admin', 'financeiro', 'producao'));

CREATE POLICY "Users see costs in their company"
  ON costs FOR SELECT
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id()));

CREATE POLICY "Financeiro/Admin manage costs"
  ON costs FOR ALL
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id())
    AND auth_user_role() IN ('admin', 'financeiro'));

CREATE POLICY "Users see sponsors in their company"
  ON sponsors FOR SELECT
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id()));

CREATE POLICY "Financeiro/Admin manage sponsors"
  ON sponsors FOR ALL
  USING (evento_id IN (SELECT id FROM events WHERE empresa_id = auth_empresa_id())
    AND auth_user_role() IN ('admin', 'financeiro', 'producao'));

CREATE POLICY "Users see sales in their company"
  ON sales FOR SELECT USING (empresa_id = auth_empresa_id());

CREATE POLICY "Financeiro/Admin manage sales"
  ON sales FOR ALL
  USING (empresa_id = auth_empresa_id()
    AND auth_user_role() IN ('admin', 'financeiro'));

CREATE POLICY "Users see system settings in their company"
  ON system_settings FOR SELECT USING (empresa_id = auth_empresa_id());

CREATE POLICY "Admins manage system settings"
  ON system_settings FOR ALL
  USING (empresa_id = auth_empresa_id() AND auth_user_role() = 'admin');

-- ─── VIEWS ────────────────────────────────────────────────────

-- Event full summary view
CREATE VIEW v_event_summary AS
SELECT
  e.id,
  e.empresa_id,
  e.nome,
  e.slug,
  e.data,
  e.cidade,
  e.local,
  e.capacidade,
  e.status,
  e.imagem_url,
  -- Settings
  es.ticket_medio_ingresso,
  es.ticket_medio_ab,
  es.participacao_lab,
  es.meta_receita,
  es.meta_publico,
  es.publico_atual,
  es.cortesias,
  es.publico_conservador,
  es.publico_realista,
  es.publico_agressivo,
  -- Bilheteria
  COALESCE(
    (SELECT SUM(valor_liquido) FROM sales WHERE evento_id = e.id AND status = 'confirmado'), 0
  ) AS bilheteria_liquida,
  COALESCE(
    (SELECT SUM(quantidade) FROM sales WHERE evento_id = e.id AND status = 'confirmado'), 0
  ) AS ingressos_vendidos,
  -- Bar
  COALESCE(
    (SELECT SUM(receita_empresa) FROM bar_sales WHERE evento_id = e.id), 0
  ) AS receita_bar,
  -- Patrocínios
  COALESCE(
    (SELECT SUM(valor) FROM sponsors WHERE evento_id = e.id AND status = 'confirmado'), 0
  ) AS patrocinio_confirmado,
  COALESCE(
    (SELECT SUM(valor) FROM sponsors WHERE evento_id = e.id), 0
  ) AS patrocinio_total,
  -- Custos
  COALESCE(
    (SELECT artistico+estrutura+marketing+producao+equipe+operacao+impostos+outros
     FROM costs WHERE evento_id = e.id), 0
  ) AS custo_total,
  -- Days remaining
  GREATEST(0, EXTRACT(DAY FROM (e.data::timestamptz - NOW()))::INTEGER) AS dias_restantes
FROM events e
LEFT JOIN event_settings es ON es.evento_id = e.id;

-- ─── DEFAULT SYSTEM SETTINGS INSERT FUNCTION ──────────────────

CREATE OR REPLACE FUNCTION init_company_settings(p_empresa_id UUID)
RETURNS VOID AS $$
BEGIN
  INSERT INTO system_settings (empresa_id, chave, valor, tipo, descricao, grupo) VALUES
    (p_empresa_id, 'titulo_dashboard',    'Além do Óbvio',             'string',  'Título principal do dashboard', 'identidade'),
    (p_empresa_id, 'slogan',              'Central de Decisão para Eventos', 'string', 'Slogan',                   'identidade'),
    (p_empresa_id, 'ticket_medio_ab',     '100',                        'number',  'Ticket médio padrão A&B',      'financeiro'),
    (p_empresa_id, 'participacao_bar',    '0.5',                        'number',  'Participação % no bar',        'financeiro'),
    (p_empresa_id, 'mostrar_demo',        'false',                      'boolean', 'Exibir dados de demonstração', 'sistema'),
    (p_empresa_id, 'cor_primaria',        '#C7A86B',                    'color',   'Cor primária da marca',        'aparencia'),
    (p_empresa_id, 'cor_secundaria',      '#8B5CF6',                    'color',   'Cor secundária da marca',      'aparencia'),
    (p_empresa_id, 'timezone',            'America/Bahia',              'string',  'Fuso horário',                 'sistema')
  ON CONFLICT (empresa_id, chave) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ─── REALTIME ─────────────────────────────────────────────────

ALTER PUBLICATION supabase_realtime ADD TABLE events;
ALTER PUBLICATION supabase_realtime ADD TABLE sales;
ALTER PUBLICATION supabase_realtime ADD TABLE alerts;
ALTER PUBLICATION supabase_realtime ADD TABLE bar_sales;
