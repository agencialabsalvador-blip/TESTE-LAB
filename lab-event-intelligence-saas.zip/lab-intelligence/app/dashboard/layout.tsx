'use client'

import { useState, useEffect } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import Link from 'next/link'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, CalendarDays, Wallet, GitBranch, Brain,
  Bell, GlassWater, Upload, Plus, Settings, User as UserIcon,
  ChevronLeft, ChevronRight, Activity, LogOut, Building2,
  Users, Shield, Plug, FileText,
} from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { cn } from '@/lib/utils'

const NAV_MAIN = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/eventos', label: 'Eventos', icon: CalendarDays },
  { href: '/financeiro', label: 'Financeiro', icon: Wallet },
  { href: '/cenarios', label: 'Cenários', icon: GitBranch },
  { href: '/decisao', label: 'Central de Decisão', icon: Brain },
  { href: '/alertas', label: 'Alertas', icon: Bell },
  { href: '/volumetria', label: 'Volumetria A&B', icon: GlassWater },
  { href: '/importacoes', label: 'Importações', icon: Upload },
  { href: '/eventos/novo', label: 'Novo Evento', icon: Plus },
]

const NAV_ADMIN = [
  { href: '/admin/empresa', label: 'Empresa', icon: Building2 },
  { href: '/admin/usuarios', label: 'Usuários', icon: Users },
  { href: '/admin/permissoes', label: 'Permissões', icon: Shield },
  { href: '/admin/integracoes', label: 'Integrações', icon: Plug },
  { href: '/admin/configuracoes', label: 'Configurações', icon: Settings },
  { href: '/admin/logs', label: 'Logs', icon: FileText },
]

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const pathname = usePathname()
  const { user, company, signOut, loading } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [adminExpanded, setAdminExpanded] = useState(false)

  useEffect(() => {
    if (!loading && !user) {
      router.push('/auth/login')
    }
  }, [user, loading, router])

  if (loading || !user) {
    return (
      <div className="flex items-center justify-center h-screen bg-lab-bg">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 rounded-xl gradient-gold gold-glow flex items-center justify-center">
            <Activity size={20} className="text-lab-bg" strokeWidth={2.6} />
          </div>
          <p className="text-lab-gray text-sm">Carregando...</p>
        </div>
      </div>
    )
  }

  const isActive = (href: string) => {
    if (href === '/dashboard') return pathname === '/dashboard'
    return pathname.startsWith(href)
  }

  return (
    <div className="flex h-screen overflow-hidden bg-lab-bg">
      {/* Sidebar */}
      <aside
        className={cn(
          'flex-shrink-0 border-r border-white/[0.05] bg-[rgba(13,15,20,0.78)] backdrop-blur-lg transition-all duration-300 overflow-hidden',
          sidebarOpen ? 'w-[238px]' : 'w-0'
        )}
      >
        <div className="w-[238px] h-full flex flex-col p-[18px_11px]">
          {/* Logo */}
          <div className="flex items-center gap-2.5 px-1.5 pb-[18px] border-b border-white/[0.05] mb-2.5">
            <div className="w-[30px] h-[30px] rounded-[9px] gradient-gold flex items-center justify-center gold-glow flex-shrink-0">
              <Activity size={15} className="text-lab-bg" strokeWidth={2.6} />
            </div>
            <div>
              <b className="text-[13px] font-black text-lab-ice tracking-[0.4px] block">
                {company?.nome ?? 'LAB'}
              </b>
              <span className="text-[7.5px] text-lab-gold tracking-[3px] font-bold uppercase">
                Intelligence
              </span>
            </div>
          </div>

          {/* Main Nav */}
          <nav className="flex flex-col gap-[1px] flex-1">
            {NAV_MAIN.map((item) => {
              const Icon = item.icon
              const active = isActive(item.href)
              return (
                <Link key={item.href} href={item.href}>
                  <span
                    className={cn(
                      'nav-item',
                      active && 'active'
                    )}
                  >
                    {active && (
                      <span className="absolute left-0 top-[7px] bottom-[7px] w-[3px] rounded-[2px] bg-lab-gold" />
                    )}
                    <Icon
                      size={16}
                      className={active ? 'text-lab-gold' : 'text-lab-gray'}
                    />
                    {item.label}
                  </span>
                </Link>
              )
            })}
          </nav>

          {/* Admin Section */}
          {user.perfil === 'admin' && (
            <div className="border-t border-white/[0.05] pt-2 mt-2">
              <button
                onClick={() => setAdminExpanded(!adminExpanded)}
                className="nav-item w-full"
              >
                <Settings size={16} className="text-lab-gray" />
                Administração
                <ChevronRight
                  size={13}
                  className={cn(
                    'ml-auto text-lab-gray transition-transform',
                    adminExpanded && 'rotate-90'
                  )}
                />
              </button>
              {adminExpanded &&
                NAV_ADMIN.map((item) => {
                  const Icon = item.icon
                  const active = isActive(item.href)
                  return (
                    <Link key={item.href} href={item.href}>
                      <span
                        className={cn(
                          'nav-item pl-6 text-[12px]',
                          active && 'active'
                        )}
                      >
                        <Icon size={14} className={active ? 'text-lab-gold' : 'text-lab-gray'} />
                        {item.label}
                      </span>
                    </Link>
                  )
                })}
            </div>
          )}

          {/* User footer */}
          <div className="border-t border-white/[0.05] pt-2 mt-2">
            <Link href="/perfil">
              <span className="nav-item">
                <UserIcon size={16} />
                {user.nome}
              </span>
            </Link>
            <button className="nav-item w-full" onClick={signOut}>
              <LogOut size={16} />
              Sair
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="flex items-center gap-3 px-[22px] py-[13px] border-b border-white/[0.05] bg-[rgba(13,15,20,0.68)] backdrop-blur-lg flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1.5 rounded-[7px] text-lab-gray hover:bg-white/[0.06] hover:text-lab-ice transition-colors"
          >
            {sidebarOpen ? <ChevronLeft size={17} /> : <ChevronRight size={17} />}
          </button>

          <div className="flex-1 text-[14px] font-bold text-lab-ice" id="page-title">
            {getPageTitle(pathname)}
          </div>

          {/* Live indicator */}
          <div className="flex items-center gap-1.5 px-3 py-[5px] rounded-full bg-lab-green/10 border border-lab-green/20">
            <span className="w-[7px] h-[7px] rounded-full bg-lab-green shadow-[0_0_8px_#4ADE80] animate-pulse-dot" />
            <span className="text-[11px] text-lab-green font-semibold">Tempo real</span>
          </div>

          {/* Role badge */}
          <span className="text-[10px] font-semibold text-lab-gray uppercase tracking-widest">
            {ROLE_LABELS[user.perfil]}
          </span>

          {/* Avatar */}
          <div className="w-8 h-8 rounded-full gradient-gold flex items-center justify-center text-[12px] font-black text-lab-bg flex-shrink-0">
            {user.nome.charAt(0).toUpperCase()}
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
    </div>
  )
}

const ROLE_LABELS: Record<string, string> = {
  admin: 'Admin',
  financeiro: 'Financeiro',
  producao: 'Produção',
  marketing: 'Marketing',
  visualizacao: 'Visualização',
}

function getPageTitle(pathname: string): string {
  const map: Record<string, string> = {
    '/dashboard': 'Dashboard',
    '/eventos': 'Eventos',
    '/eventos/novo': 'Novo Evento',
    '/financeiro': 'Financeiro',
    '/cenarios': 'Cenários',
    '/decisao': 'Central de Decisão',
    '/alertas': 'Alertas',
    '/volumetria': 'Volumetria A&B',
    '/importacoes': 'Importações',
    '/admin/empresa': 'Empresa',
    '/admin/usuarios': 'Usuários',
    '/admin/permissoes': 'Permissões',
    '/admin/integracoes': 'Integrações',
    '/admin/configuracoes': 'Configurações',
    '/admin/logs': 'Logs',
  }
  return map[pathname] ?? 'LAB Intelligence'
}
