'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, DollarSign, TrendingUp, Gauge, Activity } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'
import { getDashboardSummary } from '@/services/events'
import type { DashboardSummary } from '@/types'
import { formatCurrency } from '@/lib/calculations'
import EventRadarCard from '@/components/events/EventRadarCard'
import KPICard from '@/components/dashboard/KPICard'
import HealthRing from '@/components/shared/HealthRing'

export default function DashboardPage() {
  const { company, user } = useAuth()
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!company?.id) return
    getDashboardSummary(company.id)
      .then(setSummary)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [company?.id])

  const now = new Date()
  const dow = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado']

  return (
    <div className="flex flex-col gap-6">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-2"
      >
        <div className="text-[10px] text-lab-gold font-bold tracking-[3px] uppercase">
          {company?.nome ?? 'LAB Entretenimento'} · Inteligência de Eventos
        </div>
        <h1 className="text-[42px] font-black text-lab-ice tracking-[-2px] leading-none mt-2 mb-1.5">
          {company?.configuracoes?.titulo_dashboard ?? 'Além do Óbvio'}
        </h1>
        <p className="text-lab-gray text-[13px]">
          {summary
            ? `${summary.total_eventos_ativos} eventos ativos`
            : 'Carregando...'}{' '}
          · {dow[now.getDay()]},{' '}
          {now.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}
        </p>
      </motion.div>

      {/* Executive Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="glass p-5 h-32 skeleton" />
          ))
        ) : summary ? (
          <>
            <KPICard
              label="Valor Econômico Total"
              value={formatCurrency(summary.valor_economico_total)}
              sub="Todos os eventos ativos"
              icon={<Sparkles size={15} />}
              color="#C7A86B"
              hero
              delay={0}
            />
            <KPICard
              label="Receita Realizada"
              value={formatCurrency(summary.receita_realizada)}
              sub="Confirmado em caixa"
              icon={<DollarSign size={15} />}
              color="#4ADE80"
              delay={0.07}
            />
            <KPICard
              label="Resultado Projetado"
              value={formatCurrency(summary.resultado_projetado)}
              sub="Cenário realista"
              icon={<TrendingUp size={15} />}
              color={summary.resultado_projetado >= 0 ? '#4ADE80' : '#EF4444'}
              delay={0.14}
            />
            <KPICard
              label="Saúde Geral"
              value={`${summary.saude_geral}%`}
              sub={`${summary.total_eventos_ativos} eventos monitorados`}
              icon={<Gauge size={15} />}
              color={
                summary.saude_geral > 70
                  ? '#4ADE80'
                  : summary.saude_geral > 45
                  ? '#FACC15'
                  : '#EF4444'
              }
              ring={summary.saude_geral}
              delay={0.21}
            />
          </>
        ) : null}
      </div>

      {/* Event Radar */}
      <div>
        <div className="flex items-center gap-2 mb-3.5">
          <Activity size={15} className="text-lab-gold" />
          <h2 className="text-[15px] font-bold text-lab-ice">Radar dos Eventos</h2>
        </div>

        {loading ? (
          <div className="grid gap-3.5 grid-cols-[repeat(auto-fill,minmax(260px,1fr))]">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="glass h-64 skeleton" />
            ))}
          </div>
        ) : summary?.eventos.length === 0 ? (
          <EmptyEvents />
        ) : (
          <div className="grid gap-3.5 grid-cols-[repeat(auto-fill,minmax(260px,1fr))]">
            {summary?.eventos.map((ev, i) => (
              <EventRadarCard key={ev.id} event={ev} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function EmptyEvents() {
  return (
    <div className="glass p-12 text-center">
      <div className="w-12 h-12 rounded-xl bg-lab-gold/10 flex items-center justify-center mx-auto mb-4">
        <Sparkles size={22} className="text-lab-gold" />
      </div>
      <h3 className="text-lab-ice font-bold text-lg mb-2">Nenhum evento cadastrado</h3>
      <p className="text-lab-gray text-sm">
        Crie seu primeiro evento para começar a monitorar a inteligência financeira.
      </p>
      <a href="/eventos/novo" className="btn-primary inline-block mt-5 text-sm">
        + Criar primeiro evento
      </a>
    </div>
  )
}
