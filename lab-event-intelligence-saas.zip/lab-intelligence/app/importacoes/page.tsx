'use client'

import { useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { motion } from 'framer-motion'
import { Upload, CheckCircle2, AlertTriangle, Loader2, FileSpreadsheet, Download } from 'lucide-react'
import { importFile, downloadTemplate } from '@/services/import'
import { useAuth } from '@/contexts/AuthContext'
import type { ImportPlatform } from '@/types'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

const PLATFORMS: { key: ImportPlatform; label: string; desc: string }[] = [
  { key: 'bilheteria_digital', label: 'Bilheteria Digital', desc: 'Export CSV/Excel da plataforma' },
  { key: 'sympla',             label: 'Sympla',             desc: 'Relatório de vendas Sympla' },
  { key: 'ingresse',           label: 'Ingresse',           desc: 'Extrato Ingresse' },
  { key: 'shotgun',            label: 'Shotgun',            desc: 'Export Shotgun' },
  { key: 'zig',                label: 'Zig',                desc: 'Relatório Zig' },
  { key: 'csv',                label: 'CSV Genérico',       desc: 'Arquivo CSV padrão LAB' },
  { key: 'excel',              label: 'Excel',              desc: 'Planilha Excel padrão LAB' },
]

export default function ImportacoesPage() {
  const { company } = useAuth()
  const [selectedPlatform, setSelectedPlatform] = useState<ImportPlatform>('csv')
  const [eventoId, setEventoId] = useState('')
  const [result, setResult] = useState<{ imported: number; errors: { linha: number; mensagem: string }[] } | null>(null)
  const [loading, setLoading] = useState(false)

  const onDrop = useCallback(
    async (files: File[]) => {
      const file = files[0]
      if (!file || !eventoId || !company?.id) {
        toast.error('Selecione um evento antes de importar.')
        return
      }
      setLoading(true)
      setResult(null)
      try {
        const res = await importFile(file, eventoId, company.id, selectedPlatform)
        setResult(res)
        toast.success(`${res.imported} registros importados com sucesso.`)
      } catch (e: unknown) {
        toast.error(e instanceof Error ? e.message : 'Erro na importação.')
      } finally {
        setLoading(false)
      }
    },
    [eventoId, company?.id, selectedPlatform]
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/vnd.ms-excel': ['.xls'],
    },
    multiple: false,
  })

  return (
    <div className="flex flex-col gap-6 max-w-3xl">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-[9px] bg-lab-gold/10 flex items-center justify-center">
            <Upload size={16} className="text-lab-gold" />
          </div>
          <h1 className="text-[22px] font-black text-lab-ice tracking-[-0.5px]">
            Importações
          </h1>
        </div>
        <p className="text-lab-gray text-[12px]">
          Importe vendas de qualquer plataforma. Os dados são mapeados automaticamente.
        </p>
      </motion.div>

      {/* Platform selector */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
        {PLATFORMS.map((p) => (
          <button
            key={p.key}
            onClick={() => setSelectedPlatform(p.key)}
            className={cn(
              'glass p-3 text-left transition-all duration-150',
              selectedPlatform === p.key
                ? 'border-lab-gold/40 bg-lab-gold/[0.08]'
                : 'hover:border-white/10 hover:-translate-y-0.5'
            )}
          >
            <FileSpreadsheet
              size={16}
              className={selectedPlatform === p.key ? 'text-lab-gold' : 'text-lab-gray'}
            />
            <div
              className={cn(
                'text-[12.5px] font-semibold mt-1.5',
                selectedPlatform === p.key ? 'text-lab-gold' : 'text-lab-ice'
              )}
            >
              {p.label}
            </div>
            <div className="text-[10.5px] text-lab-gray mt-0.5">{p.desc}</div>
          </button>
        ))}
      </div>

      {/* Evento selector */}
      <div className="glass p-5">
        <label className="text-[11px] text-lab-gray font-medium block mb-2">
          Evento de destino
        </label>
        <input
          type="text"
          value={eventoId}
          onChange={(e) => setEventoId(e.target.value)}
          placeholder="Cole o ID do evento (ex: uuid)"
          className="lab-input"
        />
        <p className="text-[10.5px] text-lab-gray mt-1.5">
          Acesse o evento e copie o ID da URL: /eventos/[ID]
        </p>
      </div>

      {/* Drop zone */}
      <div
        {...getRootProps()}
        className={cn(
          'border border-dashed rounded-[14px] p-10 text-center cursor-pointer transition-all',
          isDragActive
            ? 'border-lab-gold/60 bg-lab-gold/[0.06]'
            : 'border-lab-gold/25 hover:border-lab-gold/40 hover:bg-lab-gold/[0.03]'
        )}
      >
        <input {...getInputProps()} />
        {loading ? (
          <div className="flex flex-col items-center gap-3">
            <Loader2 size={28} className="text-lab-gold animate-spin" />
            <p className="text-lab-ice font-semibold">Importando...</p>
          </div>
        ) : (
          <>
            <Upload size={26} className="text-lab-gold mx-auto mb-3" />
            <h3 className="text-[14px] font-semibold text-lab-ice">
              Arraste o arquivo ou clique para selecionar
            </h3>
            <p className="text-[11.5px] text-lab-gray mt-1.5">
              CSV ou Excel (.xlsx / .xls) · Plataforma selecionada:{' '}
              <span className="text-lab-gold font-semibold">
                {PLATFORMS.find((p) => p.key === selectedPlatform)?.label}
              </span>
            </p>
          </>
        )}
      </div>

      {/* Template download */}
      <button
        onClick={downloadTemplate}
        className="inline-flex items-center gap-2 text-[12px] text-lab-gray hover:text-lab-ice transition-colors self-start"
      >
        <Download size={14} />
        Baixar template CSV padrão LAB
      </button>

      {/* Result */}
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass p-5"
        >
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 size={16} className="text-lab-green" />
            <span className="text-lab-ice font-semibold text-[14px]">
              {result.imported} registros importados
            </span>
          </div>

          {result.errors.length > 0 && (
            <div className="mt-3">
              <div className="flex items-center gap-1.5 text-lab-yellow text-[12px] font-semibold mb-2">
                <AlertTriangle size={13} />
                {result.errors.length} linha(s) ignoradas
              </div>
              <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto">
                {result.errors.slice(0, 20).map((e, i) => (
                  <div key={i} className="text-[11px] text-lab-gray">
                    Linha {e.linha}: {e.mensagem}
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  )
}
