'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { motion } from 'framer-motion'
import { Loader2, Plus, ChevronLeft } from 'lucide-react'
import { createEventSchema, type CreateEventInput } from '@/lib/validations'
import { createEvent } from '@/services/events'
import { useAuth } from '@/contexts/AuthContext'
import { toast } from 'sonner'
import Link from 'next/link'

const FIELDS = [
  { name: 'nome' as const,     label: 'Nome do evento',         type: 'text',   placeholder: 'Ex: Climinha Run 2027',    span: 2 },
  { name: 'data' as const,     label: 'Data',                   type: 'date',   placeholder: '',                          span: 1 },
  { name: 'cidade' as const,   label: 'Cidade',                 type: 'text',   placeholder: 'Salvador',                  span: 1 },
  { name: 'local' as const,    label: 'Local',                  type: 'text',   placeholder: 'Orla de Salvador',          span: 2 },
  { name: 'capacidade' as const, label: 'Capacidade (pax)',     type: 'number', placeholder: '0',                         span: 1 },
]

export default function NovoEventoPage() {
  const router = useRouter()
  const { company } = useAuth()
  const [loading, setLoading] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CreateEventInput>({
    resolver: zodResolver(createEventSchema),
  })

  const onSubmit = async (data: CreateEventInput) => {
    if (!company?.id) return
    setLoading(true)
    try {
      const ev = await createEvent(company.id, {
        nome: data.nome,
        data: data.data,
        cidade: data.cidade,
        local: data.local,
        capacidade: Number(data.capacidade),
        status: 'aguardando',
      })
      toast.success('Evento criado! Aguardando dados.')
      router.push(`/eventos/${ev.id}`)
    } catch (e) {
      toast.error('Erro ao criar evento. Tente novamente.')
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6"
      >
        <Link
          href="/eventos"
          className="inline-flex items-center gap-1.5 text-lab-gray text-[12.5px] font-medium mb-4 hover:text-lab-ice transition-colors"
        >
          <ChevronLeft size={14} />
          Voltar
        </Link>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-[9px] bg-lab-gold/10 flex items-center justify-center">
            <Plus size={16} className="text-lab-gold" />
          </div>
          <h1 className="text-[22px] font-black text-lab-ice tracking-[-0.5px]">
            Novo Evento
          </h1>
        </div>
        <p className="text-lab-gray text-[12px]">
          O evento inicia zerado com status{' '}
          <span className="text-lab-gray font-semibold">Aguardando Dados</span>.
          Adicione as configurações financeiras após a criação.
        </p>
      </motion.div>

      {/* Form */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
      >
        <div className="glass p-6">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="grid grid-cols-2 gap-4">
              {FIELDS.map((f) => (
                <div
                  key={f.name}
                  className={f.span === 2 ? 'col-span-2' : 'col-span-1'}
                >
                  <label className="text-[11px] text-lab-gray font-medium block mb-1.5">
                    {f.label}
                  </label>
                  <input
                    {...register(f.name)}
                    type={f.type}
                    placeholder={f.placeholder}
                    className="lab-input"
                  />
                  {errors[f.name] && (
                    <p className="text-lab-red text-[11px] mt-1">
                      {errors[f.name]?.message}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Optional image URL */}
            <div className="mt-4">
              <label className="text-[11px] text-lab-gray font-medium block mb-1.5">
                Imagem do evento (URL, opcional)
              </label>
              <input
                {...register('imagem_url')}
                type="url"
                placeholder="https://..."
                className="lab-input"
              />
            </div>

            <div className="mt-4">
              <label className="text-[11px] text-lab-gray font-medium block mb-1.5">
                Observações (opcional)
              </label>
              <textarea
                {...register('observacoes')}
                placeholder="Notas sobre o evento..."
                rows={3}
                className="lab-input resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center gap-2 mt-6"
            >
              {loading ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Plus size={14} />
              )}
              {loading ? 'Criando...' : 'Criar evento'}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  )
}
