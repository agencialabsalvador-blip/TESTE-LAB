'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { motion } from 'framer-motion'
import { Activity, Eye, EyeOff, Loader2 } from 'lucide-react'
import { loginSchema, type LoginInput } from '@/lib/validations'
import { useAuth } from '@/contexts/AuthContext'
import { toast } from 'sonner'

export default function LoginPage() {
  const router = useRouter()
  const { signIn } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  })

  const onSubmit = async (data: LoginInput) => {
    setLoading(true)
    const result = await signIn(data.email, data.password)
    if (result.error) {
      toast.error('Credenciais inválidas. Verifique e-mail e senha.')
      setLoading(false)
    } else {
      router.push('/dashboard')
    }
  }

  return (
    <div className="min-h-screen bg-lab-bg flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-lab-gold/[0.04] blur-[120px]" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-sm relative"
      >
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-[14px] gradient-gold flex items-center justify-center gold-glow mb-4">
            <Activity size={22} className="text-lab-bg" strokeWidth={2.6} />
          </div>
          <h1 className="text-[28px] font-black text-lab-ice tracking-[-1px]">
            LAB Intelligence
          </h1>
          <p className="text-lab-gray text-sm mt-1">
            Central de decisão para eventos
          </p>
        </div>

        {/* Card */}
        <div className="glass p-7">
          <h2 className="text-[18px] font-bold text-lab-ice mb-6">Entrar</h2>

          <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">
            {/* Email */}
            <div>
              <label className="text-[11px] text-lab-gray font-medium block mb-1.5">
                E-mail
              </label>
              <input
                {...register('email')}
                type="email"
                placeholder="seu@email.com"
                autoComplete="email"
                className="lab-input"
              />
              {errors.email && (
                <p className="text-lab-red text-[11px] mt-1">{errors.email.message}</p>
              )}
            </div>

            {/* Password */}
            <div>
              <label className="text-[11px] text-lab-gray font-medium block mb-1.5">
                Senha
              </label>
              <div className="relative">
                <input
                  {...register('password')}
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  className="lab-input pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-lab-gray hover:text-lab-ice transition-colors"
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
              {errors.password && (
                <p className="text-lab-red text-[11px] mt-1">{errors.password.message}</p>
              )}
            </div>

            {/* Forgot */}
            <div className="flex justify-end">
              <Link
                href="/auth/esqueci-senha"
                className="text-[11px] text-lab-gold hover:opacity-80 transition-opacity"
              >
                Esqueci minha senha
              </Link>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center justify-center gap-2 mt-1"
            >
              {loading && <Loader2 size={14} className="animate-spin" />}
              {loading ? 'Entrando...' : 'Entrar'}
            </button>
          </form>

          <p className="text-center text-[12px] text-lab-gray mt-5">
            Não tem conta?{' '}
            <Link href="/auth/cadastro" className="text-lab-gold hover:opacity-80">
              Criar conta
            </Link>
          </p>
        </div>

        <p className="text-center text-[11px] text-lab-gray/50 mt-6">
          LAB Entretenimento © {new Date().getFullYear()}
        </p>
      </motion.div>
    </div>
  )
}
