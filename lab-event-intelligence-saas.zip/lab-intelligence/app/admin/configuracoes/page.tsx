'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Settings, Save, Loader2, RefreshCw } from 'lucide-react'
import { createClient } from '@/lib/supabase/client'
import { useAuth } from '@/contexts/AuthContext'
import { toast } from 'sonner'
import type { SystemSettings } from '@/types'

const supabase = createClient()

const GROUPS = [
  { key: 'identidade', label: '🏷 Identidade' },
  { key: 'financeiro', label: '💰 Financeiro' },
  { key: 'aparencia', label: '🎨 Aparência' },
  { key: 'sistema', label: '⚙️ Sistema' },
]

export default function ConfiguracoesPage() {
  const { company } = useAuth()
  const [settings, setSettings] = useState<SystemSettings[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [localValues, setLocalValues] = useState<Record<string, string>>({})

  useEffect(() => {
    if (!company?.id) return
    supabase
      .from('system_settings')
      .select('*')
      .eq('empresa_id', company.id)
      .order('grupo')
      .then(({ data }) => {
        setSettings(data ?? [])
        const vals: Record<string, string> = {}
        ;(data ?? []).forEach((s) => { vals[s.chave] = s.valor })
        setLocalValues(vals)
        setLoading(false)
      })
  }, [company?.id])

  const handleChange = (chave: string, valor: string) => {
    setLocalValues((prev) => ({ ...prev, [chave]: valor }))
  }

  const handleSave = async (setting: SystemSettings) => {
    setSaving(setting.chave)
    const newVal = localValues[setting.chave]

    const { error } = await supabase
      .from('system_settings')
      .update({ valor: newVal, updated_at: new Date().toISOString() })
      .eq('id', setting.id)

    if (error) {
      toast.error('Erro ao salvar configuração.')
    } else {
      toast.success(`"${setting.descricao || setting.chave}" atualizado.`)
    }
    setSaving(null)
  }

  const handleReset = async () => {
    if (!company?.id) return
    if (!confirm('Redefinir todas as configurações para os valores padrão?')) return
    await supabase.rpc('init_company_settings', { p_empresa_id: company.id })
    toast.success('Configurações redefinidas.')
    window.location.reload()
  }

  if (loading) {
    return (
      <div className="flex flex-col gap-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="glass h-20 skeleton" />
        ))}
      </div>
    )
  }

  const byGroup = GROUPS.map((g) => ({
    ...g,
    items: settings.filter((s) => s.grupo === g.key),
  })).filter((g) => g.items.length > 0)

  return (
    <div className="max-w-2xl flex flex-col gap-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-center gap-2 mb-1">
          <div className="w-8 h-8 rounded-[9px] bg-lab-gold/10 flex items-center justify-center">
            <Settings size={16} className="text-lab-gold" />
          </div>
          <h1 className="text-[22px] font-black text-lab-ice tracking-[-0.5px]">
            Configurações
          </h1>
        </div>
        <p className="text-lab-gray text-[12px]">
          Todas as configurações podem ser alteradas aqui sem necessidade de código.
        </p>
        <button
          onClick={handleReset}
          className="mt-3 inline-flex items-center gap-1.5 text-[11px] text-lab-gray hover:text-lab-ice transition-colors"
        >
          <RefreshCw size={12} />
          Redefinir padrões
        </button>
      </motion.div>

      {/* Setting Groups */}
      {byGroup.map((group, gi) => (
        <motion.div
          key={group.key}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: gi * 0.08 }}
        >
          <div className="glass p-5">
            <h2 className="text-[13px] font-bold text-lab-ice mb-4">
              {group.label}
            </h2>
            <div className="flex flex-col gap-4">
              {group.items.map((setting) => (
                <div key={setting.chave}>
                  <label className="text-[11px] text-lab-gray font-medium block mb-1">
                    {setting.descricao || setting.chave}
                    <span className="ml-2 text-lab-gray/50 font-mono text-[10px]">
                      {setting.chave}
                    </span>
                  </label>
                  <div className="flex gap-2">
                    {setting.tipo === 'boolean' ? (
                      <select
                        value={localValues[setting.chave] ?? setting.valor}
                        onChange={(e) => handleChange(setting.chave, e.target.value)}
                        className="lab-input"
                      >
                        <option value="true">Sim</option>
                        <option value="false">Não</option>
                      </select>
                    ) : setting.tipo === 'color' ? (
                      <div className="flex items-center gap-2 flex-1">
                        <input
                          type="color"
                          value={localValues[setting.chave] ?? setting.valor}
                          onChange={(e) => handleChange(setting.chave, e.target.value)}
                          className="h-10 w-16 rounded-[8px] border border-white/[0.08] bg-transparent cursor-pointer"
                        />
                        <input
                          type="text"
                          value={localValues[setting.chave] ?? setting.valor}
                          onChange={(e) => handleChange(setting.chave, e.target.value)}
                          className="lab-input"
                        />
                      </div>
                    ) : (
                      <input
                        type={setting.tipo === 'number' ? 'number' : 'text'}
                        value={localValues[setting.chave] ?? setting.valor}
                        onChange={(e) => handleChange(setting.chave, e.target.value)}
                        className="lab-input"
                        step={setting.tipo === 'number' ? 'any' : undefined}
                      />
                    )}
                    <button
                      onClick={() => handleSave(setting)}
                      disabled={
                        saving === setting.chave ||
                        localValues[setting.chave] === setting.valor
                      }
                      className="btn-primary flex-shrink-0 flex items-center gap-1.5 px-3"
                    >
                      {saving === setting.chave ? (
                        <Loader2 size={13} className="animate-spin" />
                      ) : (
                        <Save size={13} />
                      )}
                      Salvar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  )
}
